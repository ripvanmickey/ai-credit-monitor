(()=>{
 const fmt=v=>v.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
 window.soxRefreshMarket=async()=>{try{const r=await fetch('api/market',{cache:'no-store'});if(!r.ok)throw Error();const p=await r.json();if(p.symbol!=='I:SOX'||!p.bars?.length)throw Error();
 const last=p.bars.at(-1),prev=p.bars.at(-2),delta=prev?last.close-prev.close:null,pct=prev?delta/prev.close*100:null;
 document.querySelector('.local-quote').innerHTML='<strong>'+fmt(last.close)+' <small>点</small></strong><span>'+(delta==null?'':(delta>=0?'+':'')+fmt(delta)+'（'+(pct>=0?'+':'')+pct.toFixed(2)+'%）')+'</span><small>'+last.date+' · '+last.source+'<br>'+p.note+'</small>';
 window.dispatchEvent(new CustomEvent('sox-market-update',{detail:p}));
 }catch{const q=document.querySelector('.local-quote small:last-child');if(q&&!q.textContent.includes('自动读取暂不可用'))q.append(' · 自动读取暂不可用');}};
 window.soxRefreshMarket();setInterval(window.soxRefreshMarket,60000);
})();
