let sortKey='signal',sortDirection='desc';
let all=[],cycles=[],unit='sessions',selected='2026-10-30',page=1;const $=id=>document.getElementById(id);const fmt=n=>Number(n).toLocaleString('en-US',{maximumFractionDigits:1});const pct=n=>Number(n).toFixed(2)+'%';const dash=v=>v||'尚未收复';
function bars(){
 const groups=[
  ['1—5日',1,5],
  ['6—20日',6,20],
  ['21—60日',21,60],
  ['61—120日',61,120],
  ['121—252日',121,252],
 ];
 const completed=all.filter(row=>row.reclaim_sessions!=='');
 const distribution=groups.map(([label,min,max])=>{
  const count=completed.filter(row=>row.reclaim_sessions>=min&&row.reclaim_sessions<=max).length;
  return {label,count,share:completed.length?count/completed.length*100:0};
 });
 const target=$('bars');
 target.researchChartPayload={distribution};
 if(target.renderResearchChart){
  target.renderResearchChart();
  return;
 }
 const max=Math.max(1,...distribution.map(row=>row.count));
 target.innerHTML=distribution.map(({label,count,share})=>
  `<div class="bar-row"><span>${label}</span><div class="bar-track"><div class="bar-fill" style="width:${count/max*100}%"></div></div><span class="bar-number">${count}次 · ${share.toFixed(1)}%</span></div>`
 ).join('');
}
let latestCyclePrices=[];
let archivedCycles=[];

function elapsedCalendarDays(start,end){
 return Math.round((Date.parse(end)-Date.parse(start))/86400000);
}

function trackOpenCycle(cycle,prices){
 const start=prices.findIndex(price=>price.date===cycle.signal);
 if(start<0)return cycle;
 const result={...cycle,observedThrough:cycle.signal,elapsed_sessions:0,elapsed_calendar_days:0};
 let consecutive=0;
 let lowest=prices[start];
 const record=(key,price,sessions)=>{
  result[key+'_date']=price.date;
  result[key+'_sessions']=sessions;
  result[key+'_calendar_days']=elapsedCalendarDays(cycle.signal,price.date);
 };
 for(let i=start+1;i<prices.length;i++){
  const price=prices[i],sessions=i-start;
  result.observedThrough=price.date;
  result.elapsed_sessions=sessions;
  result.elapsed_calendar_days=elapsedCalendarDays(cycle.signal,price.date);
  if(price.close<lowest.close&&!result.peak_recovery_date)lowest=price;
  consecutive=Number.isFinite(price.ma)&&price.close>=price.ma?consecutive+1:0;
  if(consecutive===1&&!result.reclaim_date)record('reclaim',price,sessions);
  if(consecutive===5&&!result.effective_reclaim_date)record('effective_reclaim',price,sessions);
  if(price.close>=cycle.prior_peak&&!result.peak_recovery_date)record('peak_recovery',price,sessions);
  if(result.effective_reclaim_date&&result.peak_recovery_date)break;
 }
 result.lowest_date=lowest.date;
 result.additional_loss_pct=(lowest.close/cycle.close-1)*100;
 result.peak_to_low_pct=(lowest.close/cycle.prior_peak-1)*100;
 return result;
}

function refreshCycleTimeline(){
 cycles=archivedCycles.map(cycle=>cycle.peak_recovery_date?cycle:trackOpenCycle(cycle,latestCyclePrices));
 chart();
}
window.addEventListener('sox-cycle-prices',event=>{
 latestCyclePrices=event.detail;
 if(archivedCycles.length)refreshCycleTimeline();
});

function chart(){
 const max=Math.max(1,...cycles.flatMap(row=>['peak_recovery','effective_reclaim','reclaim','elapsed'].map(key=>Number(row[key+'_'+unit])||0)));
 const suffix=unit==='sessions'?'交易日':'自然日';
 const timeline=$('cycle-chart');

 function milestone(value,kind,label,pendingText,elapsed){
  const pending=value==='';
  const days=pending?elapsed:value;
  const width=Math.log1p(days)/Math.log1p(max)*100;
  const text=pending?pendingText+(days?' · '+fmt(days)+' '+suffix:''):fmt(days);
  return `<span class="cycle-track ${pending?'is-pending':''}" style="--milestone-width:${width}%">
   <span class="cycle-bar milestone-${kind}"></span>
   <span class="cycle-screen-reader">${label}</span>
   <small>${text}${pending?'':'<span class="cycle-screen-reader">'+suffix+'</span>'}</small>
  </span>`;
 }

 timeline.innerHTML=cycles.map(row=>{
  const first=row['reclaim_'+unit];
  const confirmed=row['effective_reclaim_'+unit];
  const peak=row['peak_recovery_'+unit];
  const active=selected===row.signal;
  const elapsed=row['elapsed_'+unit]??0;
  const cause=cycleCauses[row.signal]?.title||'';
  return `<li class="cycle-timeline-item">
   <button type="button" class="cycle-row ${active?'selected':''}" data-signal="${row.signal}" aria-pressed="${active}">
    <span class="cycle-date"><time datetime="${row.signal}">${row.signal}</time><small class="cycle-cause-tag">${cause}</small></span>
    <span class="cycle-tracks">
     ${milestone(first,'first','首次站回200日线','尚未站回',elapsed)}
     ${milestone(confirmed,'confirmed','有效站回年线','尚未确认',elapsed)}
     ${milestone(peak,'peak','收复历史前高','尚未收复',elapsed)}
    </span>
    <span class="cycle-end">${row.peak_recovery_date||'进行中'}</span>
   </button>
  </li>`;
 }).join('');

 timeline.querySelectorAll('button[data-signal]').forEach(button=>{
  button.onclick=()=>{
   selected=button.dataset.signal;
   timeline.querySelectorAll('button[data-signal]').forEach(item=>{
    const active=item===button;
    item.classList.toggle('selected',active);
    item.setAttribute('aria-pressed',String(active));
   });
   detail();
  };
 });
 detail();
}
function detail(){
 showCycleCause('cycle-cause',selected);
 const row=cycles.find(cycle=>cycle.signal===selected);
 const suffix=unit==='sessions'?'个交易日':'个自然日';
 const elapsed=row.observedThrough?'截至 '+row.observedThrough+' 已过 '+row['elapsed_'+unit]+suffix:'';
 const duration=key=>row[key+'_date']?row[key+'_'+unit]+suffix:elapsed;
 $('cycle-detail').innerHTML=`<div><label>周期起点 / 首次跌破</label><strong>${row.signal}</strong><small>原前高：${row.prior_peak_date} · ${fmt(row.prior_peak)}点</small></div><div><label>首次站回200日线</label><strong>${row.reclaim_date||'尚未站回'}</strong><small>${duration('reclaim')}</small></div><div><label>有效站回 · 连续5日确认</label><strong>${row.effective_reclaim_date||'尚未确认'}</strong><small>${duration('effective_reclaim')}</small></div><div><label>跌破后至最低点</label><strong>${pct(row.additional_loss_pct)}</strong><small>最低收盘日期：${row.lowest_date}</small></div><div><label>前高至最低点</label><strong>${pct(row.peak_to_low_pct)}</strong><small>${row.peak_recovery_date?'收复前高：'+row.peak_recovery_date:'收复前高：进行中'}</small></div>`;
}
function table(){let data=($('sample').value==='cycles'?archivedCycles:all).filter(r=>($('year').value==='all'||r.signal.startsWith($('year').value))&&($('status').value==='all'||($('status').value==='open'?r.reclaim_sessions==='':$('status').value==='done'?r.reclaim_sessions!=='':r.reclaim_sessions!==''&&r.reclaim_sessions>20)));data.sort(compareRows);updateHeaders();let pages=Math.max(1,Math.ceil(data.length/12));page=Math.min(page,pages);$('records').innerHTML=data.slice((page-1)*12,page*12).map(r=>`<tr><td>${r.signal}</td><td class="${r.reclaim_date?'':'pending'}">${r.reclaim_date||'尚未站回'}</td><td>${r.reclaim_sessions===''?'—':fmt(r.reclaim_sessions)}</td><td class="${r.effective_reclaim_date?'':'pending'}">${r.effective_reclaim_date||'尚未确认'}</td><td>${r.effective_reclaim_sessions===''?'—':fmt(r.effective_reclaim_sessions)}</td><td>${dash(r.peak_recovery_date)}</td><td>${r.peak_recovery_sessions===''?'—':fmt(r.peak_recovery_sessions)}</td><td class="loss">${pct(r.additional_loss_pct)}</td><td class="loss">${pct(r.peak_to_low_pct)}</td></tr>`).join('')||'<tr><td colspan="9" style="text-align:center;padding:40px">没有符合条件的样本，请调整筛选。</td></tr>';$('count').textContent=`共 ${data.length} 条记录`;$('page').textContent=`${page} / ${pages}`;$('prev').disabled=page===1;$('next').disabled=page===pages}
async function init(){try{[all,archivedCycles]=await Promise.all([fetch('all_signals.json').then(r=>r.json()),fetch('cycles.json').then(r=>r.json())]);[...new Set(all.map(r=>r.signal.slice(0,4)))].sort().reverse().forEach(y=>$('year').add(new Option(y,y)));bars();refreshCycleTimeline();initHeaders();table();['sample','year','status','sort'].forEach(id=>$(id).onchange=()=>{page=1;if(id==='sort')applyPreset();table()});$('prev').onclick=()=>{page--;table()};$('next').onclick=()=>{page++;table()};$('reset').onclick=()=>{['sample','year','status','sort'].forEach(id=>$(id).selectedIndex=0);$('sort').value='new';sortKey='signal';sortDirection='desc';page=1;table()};document.querySelectorAll('[data-unit]').forEach(b=>b.onclick=()=>{unit=b.dataset.unit;document.querySelectorAll('[data-unit]').forEach(x=>x.classList.toggle('active',x===b));chart()})}catch(e){$('records').innerHTML='<tr><td colspan="9">数据加载失败，请刷新重试。</td></tr>';console.error(e)}}init();

function compareRows(a,b){
 const av=a[sortKey],bv=b[sortKey],am=av===''||av==null,bm=bv===''||bv==null;
 if(am||bm)return am===bm?b.signal.localeCompare(a.signal):am?1:-1;
 const result=typeof av==='number'?av-bv:String(av).localeCompare(String(bv));
 return (sortDirection==='asc'?result:-result)||b.signal.localeCompare(a.signal);
}
function updateHeaders(){document.querySelectorAll('th[data-key]').forEach(th=>{const active=th.dataset.key===sortKey;th.setAttribute('aria-sort',active?(sortDirection==='asc'?'ascending':'descending'):'none');th.querySelector('.sort-arrow').textContent=active?(sortDirection==='asc'?'↑':'↓'):'↕';th.querySelector('button').title=active?'点击切换为'+(sortDirection==='asc'?'降序':'升序'):'点击按此列排序'});}
function applyPreset(){const presets={new:['signal','desc'],old:['signal','asc'],slow:['reclaim_sessions','desc'],loss:['additional_loss_pct','asc']};[sortKey,sortDirection]=presets[$('sort').value]||[sortKey,sortDirection];}
function initHeaders(){const keys=['signal','reclaim_date','reclaim_sessions','effective_reclaim_date','effective_reclaim_sessions','peak_recovery_date','peak_recovery_sessions','additional_loss_pct','peak_to_low_pct'];document.querySelectorAll('#explorer thead th').forEach((th,i)=>{const label=th.getAttribute('data-source-label')||th.textContent;th.dataset.key=keys[i];th.innerHTML='<button type="button" class="header-sort" aria-label="'+label+(i===2?'（站回年线）':i===4?'（有效站回）':i===6?'（收复前高）':'')+'排序">'+label+' <span class="sort-arrow" aria-hidden="true">↕</span></button>';th.querySelector('button').onclick=()=>{sortDirection=sortKey===keys[i]?(sortDirection==='asc'?'desc':'asc'):(keys[i]==='signal'?'desc':'asc');sortKey=keys[i];$('sort').value='custom';page=1;table()}});}
