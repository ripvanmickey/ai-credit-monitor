const json=p=>new Response(JSON.stringify(p),{headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const nyDate=t=>new Intl.DateTimeFormat('en-CA',{timeZone:'America/New_York',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date(t));
function parseBars(p){
 if(p.ticker!=='I:SOX'||p.status!=='OK'||!Array.isArray(p.results)||!p.results.length)throw Error('invalid SOX data');
 const seen=new Set();return p.results.map(b=>{if(![b.o,b.h,b.l,b.c,b.t].every(Number.isFinite)||b.c<=0||b.l<=0||b.l>Math.min(b.o,b.c)||b.h<Math.max(b.o,b.c))throw Error('invalid OHLC');const date=nyDate(b.t);if(seen.has(date))throw Error('duplicate date');seen.add(date);return {date,open:b.o,high:b.h,low:b.l,close:b.c,source:'Massive / I:SOX'};}).sort((a,b)=>a.date.localeCompare(b.date));
}
export default {async fetch(req,env,ctx){
 const url=new URL(req.url);if(req.method!=='GET'&&req.method!=='HEAD')return new Response('Method not allowed',{status:405});
 if(url.pathname==='/api/market'){
  const cache=globalThis.caches?.default,cacheKey=new Request(url.origin+'/api/market-cache-v1');
  const cached=cache&&await cache.match(cacheKey);if(cached)return cached;
  let payload;
  try{
   if(!env.MASSIVE_API_KEY)throw Error('not_configured');
   const to=nyDate(Date.now()),from=nyDate(Date.now()-14*86400000);
   const r=await fetch('https://api.massive.com/v2/aggs/ticker/I:SOX/range/1/day/'+from+'/'+to+'?sort=asc&limit=30',{headers:{Authorization:'Bearer '+env.MASSIVE_API_KEY},redirect:'error',signal:AbortSignal.timeout(12000)});
   if(!r.ok)throw Error('upstream_'+r.status);
   const liveBars=parseBars(await r.json());
   const bars=[...new Map([...FALLBACK.bars,...liveBars].map(bar=>[bar.date,bar])).values()].sort((a,b)=>a.date.localeCompare(b.date));
   payload={symbol:'I:SOX',provider:bars.at(-1).source,mode:'daily_aggregates',checkedAt:new Date().toISOString(),bars,status:'ok',note:'最新可用日线；账户未获实时快照权限，不保证实时。'};
  }catch(e){payload={...FALLBACK,status:'fallback',checkedAt:new Date().toISOString(),note:e.message==='not_configured'?'服务端数据源尚未启用，显示已保存的日线。':'数据源暂不可用，显示已保存的日线。'};}
  const response=json(payload),stored=new Response(response.clone().body,{headers:{...Object.fromEntries(response.headers),'Cache-Control':'public, max-age=60'}});
  if(cache)ctx.waitUntil(cache.put(cacheKey,stored));return response;
 }
 const path=url.pathname==='/'?'/index.html':url.pathname;
 if(!Object.hasOwn(ASSETS,path))return new Response('Not found',{status:404});
 const ext=path.split('.').at(-1),type={html:'text/html',js:'text/javascript',css:'text/css',json:'application/json',csv:'text/csv',md:'text/markdown',woff2:'font/woff2',txt:'text/plain'}[ext]||'application/octet-stream';
 const data=Uint8Array.from(atob(ASSETS[path]),c=>c.charCodeAt(0));
 return new Response(req.method==='HEAD'?null:data,{headers:{'Content-Type':type+(type.startsWith('text/')?'; charset=utf-8':''),'Cache-Control':ext==='woff2'?'public, max-age=86400':'no-cache','X-Content-Type-Options':'nosniff'}});
}};
