import {build} from 'esbuild';
import {spawnSync} from 'node:child_process';
import {readdir,rm,writeFile} from 'node:fs/promises';
import {basename,join} from 'node:path';

const output = 'cycle-public';
const {outputFiles} = await build({
  entryPoints: {design: 'ui/main.tsx'},
  outdir: output,
  chunkNames: 'design-chunk-[hash]',
  bundle: true,
  splitting: true,
  minify: true,
  format: 'esm',
  jsx: 'automatic',
  target: 'es2020',
  write: false,
});

const generated = new Set(outputFiles.map(file => basename(file.path)));
await Promise.all(outputFiles.map(file => writeFile(file.path, file.contents)));
for (const file of await readdir(output)) {
  if (/^design-chunk-[A-Z0-9]+\.js$/.test(file) && !generated.has(file)) {
    await rm(join(output, file));
  }
}

const css = spawnSync(process.execPath, [
  'node_modules/@tailwindcss/cli/dist/index.mjs',
  '-i', 'ui/theme.css',
  '-o', join(output, 'design.css'),
  '--minify',
], {stdio: 'inherit'});
if (css.error) throw css.error;
if (css.status !== 0) process.exit(css.status ?? 1);
