import fs from 'node:fs/promises';
const seed=JSON.parse(await fs.readFile('seed.json','utf8')),study=JSON.parse(await fs.readFile('trade-study.json','utf8'));
const cnbc='https://huelv.com/newsroom/51801-the-ai-credit-card-is-getting-costlier-as-coreweave-bond-yield-tops-16';
const interview='https://www.benzinga.com/markets/bonds/26/11/62990235/nasdaq-100-worst-day-credit-markets-coreweave-oracle-spacex-cds';
const softbank='https://www.marketscreener.com/news/softbank-credit-risk-jumps-to-4-year-high-as-ai-fears-roil-market-ce785fdddf8bf222';
const added=[];
function quote(entityId,date,value,operator,tenor,sourceTitle,sourceUrl,publishedAt,note,suffix=''){added.push({id:entityId+'-'+date+'-'+(sourceUrl===cnbc?'cnbc-dbreport':sourceUrl===softbank?'reuters-markit':sourceUrl===interview?'benzinga-spglobal':'tokenpost')+suffix,entityId,asOf:date,value,operator,tenor,currency:null,seniority:null,restructuring:null,kind:'reported',quoteType:'press_report',sourceTitle,sourceUrl,publishedAt,collectedAt:new Date().toISOString(),note});}
quote('CRWV','2026-11-05',1289,'>','5Y','CNBC / HUE · Deutsche Bank reported CDS',cnbc,'2026-11-06','报道明确Thursday对应11月5日，五年期盘中超过1289bp，是下界，不是精确收盘。其他合约条款未注明。');
quote('CRWV','2026-11-06',1155,'~','5Y','CNBC / HUE · Deutsche Bank reported CDS',cnbc,'2026-11-06','报道明确Friday对应11月6日，约1155bp；保留约数，不计算精确日变动。CNBC原站当前不可读取，使用注明出处的全文转载核验。');
quote('CRWV','2026-10-27',1041.4,'=','5Y','TokenPost · CoreWeave five-year CDS', 'https://www.tokenpost.com/news/investing/42120','2026-10-27','原文给出五年期1041.4bp，但未注明报价供应商及其他条款；独立点位，不与其他来源计算涨跌。');
quote('NVDA','2026-11-06',139,'~',null,'CNBC / HUE · AI credit costs',cnbc,'2026-11-06','按报道日期记录约139bp；原文该段未注明独立报价时刻及期限，不并入五年期日线或成交序列。');
quote('ORCL','2026-11-06',298,'~',null,'CNBC / HUE · AI credit costs',cnbc,'2026-11-06','按报道日期记录约298bp；该段未注明期限及独立报价时刻，保留为报道点，不覆盖日线。');
quote('GOOGL','2026-11-05',92,'=','5Y','Benzinga · S&P Global credit interview',interview,'2026-11-06','报道回顾周四；同段讨论五年期CDS，Alphabet为92bp；币种和其他条款未独立注明。');
quote('AMZN','2026-11-05',100,'=','5Y','Benzinga · S&P Global credit interview',interview,'2026-11-06','报道回顾周四五年期CDS约翻倍至100bp，不作为交易商日线收盘，也不覆盖Investing日线。');
quote('SPCX','2026-11-05',296,'=',null,'Benzinga · S&P Global credit interview',interview,'2026-11-06','原文Thursday为11月5日，SpaceX CDS为296bp；该段未独立注明期限，单独保留，不与Investing日线混算。');
quote('SFTBY','2026-11-06',457.5,'=','5Y','Reuters / MarketScreener · Markit data',softbank,'2026-11-06','原文明确06:53 GMT的五年期报价457.50bp；该日曾触及466bp是另一时点，未当作最新收盘值。');
quote('SFTBY','2026-11-06',466,'=','5Y','Reuters / MarketScreener · Markit intraday high',softbank,'2026-11-06','原文为当日日内最高触及466bp，并非06:53 GMT报价或收盘；在图中单独标注日内高点。','-intraday-high');
// Give the stated-time observation priority over a same-day intraday extreme.
added.find(o=>o.id==='SFTBY-2026-11-06-reuters-markit').observedAt='2026-11-06T06:53:00Z';
added.find(o=>o.id.endsWith('-intraday-high')).isIntradayExtreme=true;
for(const o of added)if(!seed.observations.some(v=>v.id===o.id))seed.observations.push(o);
const event={id:'crwv-upfront-20261105',date:'2026-11-05',entityId:'CRWV',title:'CoreWeave CDS改以23个预付点报价',summary:'S&P Global受访者称预付报价从20点升至23点，参考优先无担保债务。23点是名义本金的23%，不是23bp；未据此反推等价利差。',url:interview,source:'Benzinga / S&P Global'};
if(!seed.events.some(e=>e.id===event.id))seed.events.push(event);
seed.tradeStudy=study;
seed.reportSources=[{entityId:'CRWV',url:cnbc,title:'CNBC公开转载 · 德银CDS数据'},{entityId:'SFTBY',url:softbank,title:'Reuters · Markit'},{entityId:'GOOGL',url:interview,title:'Benzinga · S&P Global访谈'}];
for(const e of seed.entities){const a=study.summary[e.id];if(['GOOGL','META','NVDA','AVGO'].includes(e.id))e.note='已取得DTCC明示成交利差，按成交日计算约五年期USD优先CDS中位数；不是每日收盘报价。';if(e.id==='CRWV')e.note='最新五年期报道为11月6日约1155bp；DTCC可核验记录以固定票息加预付款为主，未将其转换成市场利差。';if(['IREN','NBIS','EQIX','DLR'].includes(e.id))e.note='已检索'+study.from+'至'+study.to+'的DTCC公开披露：命中'+a.disclosures+'条记录，未取得满足筛选条件的约五年期明示利差。不能据此断言不存在CDS市场。';}
seed.checkedAt=new Date().toISOString();seed.revision='coverage-'+Date.now();seed.checkNote='补充CoreWeave等公司的近期报道，并核验67份DTCC公开信用衍生品文件。成交中位数与日线、报道点分开统计。';
await fs.writeFile('seed.json',JSON.stringify(seed,null,2)+'\n');
await fs.writeFile('coverage-batch.json',JSON.stringify({observations:added,events:[event],tradeStudy:study},null,2)+'\n');
console.log(JSON.stringify({newReports:added.length,studySeries:study.series.length,tradeObservationDays:study.series.reduce((n,s)=>n+s.rows.length,0)}));
