import copy,importlib.util
spec=importlib.util.spec_from_file_location('collector','scripts/collect-dtcc.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
def trade(identifier,action='NEWT',parent='',spread='.0123',fixed='',expiration='2031-12-20'):
 return {'entityId':'NVDA','fileDate':'2026-10-01','sourceUrl':'https://pddata.dtcc.com/ppd/api/report/cumulative/sec/SEC_CUMULATIVE_CREDITS_2026_10_01.zip','raw':{'Dissemination Identifier':identifier,'Original Dissemination Identifier':parent,'Action type':action,'Event type':'TRAD' if action=='NEWT' else '', 'Event timestamp':'2026-10-01T16:00:00Z','Execution Timestamp':'2026-10-01T15:00:00Z','Expiration Date':expiration,'UPI FISN':'NA/CDS Corp SN Sr','Notional currency-Leg 1':'USD','Package indicator':'FALSE','Non-standardized term indicator':'FALSE','Fixed rate-Leg 1':fixed,'Spread-Leg 1':spread,'Spread notation-Leg 1':'3'}}
def derive(rows):return module.derive([{'day':'2026-10-01','status':'ok','url':'https://pddata.dtcc.com/','matches':rows}],'2026-09-01','2026-11-06','2026-11-07T00:00:00Z')
result=derive([trade('1'),trade('1'),trade('2',spread='.014')]);row=result['series'][0]['rows'][0]
assert row['tradeCount']==2 and abs(row['value']-131.5)<1e-9
assert derive([trade('1'),trade('2','EROR','1')])['series']==[]
assert abs(derive([trade('1'),trade('2','CORR','1',spread='.015')])['series'][0]['rows'][0]['value']-150)<1e-9
assert derive([trade('1',spread='',fixed='.05')])['series']==[]
assert derive([trade('1',spread='.05',fixed='.05')])['series']==[]
assert derive([trade('1',expiration='2026-11-01')])['series']==[]
assert derive([trade('1',spread='398')])['series']==[]
print('PASS: disclosure-ID dedup, decimal spread units, midpoint median, EROR withdrawal, CORR replacement, fixed-coupon/upfront exclusion, short-tenor exclusion and invalid decimal rejection')
