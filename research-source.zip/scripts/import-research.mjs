import fs from 'node:fs/promises';
import assert from 'node:assert/strict';
const seed=JSON.parse(await fs.readFile('seed.json','utf8'));
const researched=JSON.parse(await fs.readFile('researched-series.json','utf8'));
const csv=(await fs.readFile('../../outputs/cds-data/oracle-5y-cds-20261007-20261105.csv','utf8')).replace(/^\uFEFF/,'').trim().split(/\r?\n/).slice(1);
researched.push({ticker:'ORCL5YUSAX',sourceUrl:'https://www.investing.com/rates-bonds/oracle-corporation-cds-5-year-usd-historical-data',sourceId:'investing',tenor:'5Y',currency:'USD',seniority:null,restructuring:null,measure:'indicative_daily_close_bp',fetchedAt:new Date().toISOString(),rows:csv.map(line=>{const [date,close,open,high,low,changePct]=line.split(',').map(v=>v.replace(/^"|"$/g,''));return {date,close:+close,open:+open,high:+high,low:+low,changePct:+changePct};})});
const mapping={AMD5YUSAX:'AMD',INTC5YUSAX:'INTC',SPEE5YUSAX:'SPCX',AMZN5YUSAX:'AMZN',MSFT5YUSAX:'MSFT',ORCL5YUSAX:'ORCL'};
for(const e of [{id:'AMD',name:'AMD',group:'硬件 / 投资',note:'已核验5年期美元CDS公开日线。'},{id:'INTC',name:'Intel',group:'硬件 / 投资',note:'已核验5年期美元CDS公开日线。'},{id:'SPCX',name:'SpaceX',group:'硬件 / 投资',note:'AI融资链辅助观察对象；以来源页面SPCX标的为准。'},{id:'AVGO',name:'Broadcom',group:'硬件 / 投资',note:'已核验Bloomberg转述的ICE五年期CDS观测值，暂无连续日线。'}])if(!seed.entities.some(v=>v.id===e.id))seed.entities.push(e);
for(const id of ['MSFT','AMZN'])seed.entities.find(e=>e.id===id).note='已核验5年期美元CDS公开日线；关注自身利差变化与现金流。';
seed.entities.find(e=>e.id==='GOOGL').note='有Bloomberg报道观测值；未核验到连续更新的公开日线。';
seed.entities.find(e=>e.id==='META').note='有Reuters五年期CDS观测值；暂无连续日线。';
seed.entities.find(e=>e.id==='NVDA').note='有Benzinga转述S&P Global的五年期CDS观测值；暂无连续日线。';
const additions=[];
seed.dailySources=researched.map(s=>({entityId:mapping[s.ticker],ticker:s.ticker,url:s.sourceUrl,sourceId:s.sourceId,tenor:s.tenor,currency:s.currency,seniority:null,restructuring:null,quoteType:'daily_close',measure:s.measure}));
for(const s of researched){assert.ok(s.rows.length>=20);let prev=null;for(const row of s.rows){assert.ok(row.high>=Math.max(row.open,row.close)&&row.low<=Math.min(row.open,row.close));if(prev)assert.ok(row.date>prev);prev=row.date;additions.push({id:'investing-'+mapping[s.ticker]+'-'+row.date,entityId:mapping[s.ticker],asOf:row.date,value:row.close,operator:'=',tenor:'5Y',currency:'USD',seniority:null,restructuring:null,kind:'reported',quoteType:'daily_close',seriesKey:'investing:'+s.ticker,sourceId:'investing',instrument:s.ticker,open:row.open,high:row.high,low:row.low,sourceChangePct:row.changePct,sourceTitle:'Investing.com · '+s.ticker+' historical data',sourceUrl:s.sourceUrl,publishedAt:row.date,collectedAt:s.fetchedAt,note:'公开历史表的日线收盘参考值，单位bp，非可成交报价。publishedAt按来源日线日期记录，未提供独立发布时间；偿付顺序和重组条款未注明。'});}}
const bz='https://www.benzinga.com/markets/bonds/26/10/62623350/nvidia-credit-risk-cds-tripled-passes-meta-coreweave';
const bs='https://www.business-standard.com/world-news/credit-swaps-for-tech-companies-reach-records-amid-supply-concerns-126103000211_1.html';
const reuters='https://www.streetinsider.com/Reuters/Meta%2Bshares%2Bslide,%2Bdefault%2Binsurance%2Bhits%2Brecord%2Bas%2BAI%2Bspending%2Balarms%2Binvestors/27219472.html';
function report(entityId,date,value,tenor,sourceTitle,sourceUrl,publishedAt,note,operator='='){additions.push({id:entityId+'-'+date+'-'+(sourceUrl===bz?'spglobal':sourceUrl===bs?'ice':'reuters'),entityId,asOf:date,value,operator,tenor,currency:null,seniority:null,restructuring:null,kind:'reported',quoteType:'press_report',sourceTitle,sourceUrl,publishedAt,note});}
for(const [date,value] of [['2026-10-12',87],['2026-10-22',118],['2026-10-23',130],['2026-10-27',127]])report('NVDA',date,value,'5Y','Benzinga · S&P Global CDS data',bz,'2026-10-27','文章明确描述五年期CDS。报道点位而非日线收盘；其他合约条款未注明，不并入连续日线。');
report('CRWV','2026-10-22',1167,null,'Benzinga · S&P Global CDS data',bz,'2026-10-27','文章给出10月22日点位，所引CoreWeave段落未独立注明期限及币种，保留未知，不并入日线分析。');
report('META','2026-10-22',114.79,'5Y','Reuters / StreetInsider · Meta default insurance',reuters,'2026-10-22','报道为当日盘中五年期CDS，币种等条款未注明，不作日线收盘。');
report('AVGO','2026-10-29',175.4,'5Y','Bloomberg / Business Standard · ICE CDS data',bs,'2026-10-30','报道明确五年期，日期由原文Thursday对应10月29日；其他合约条款未注明。');
report('GOOGL','2026-10-29',84,null,'Bloomberg / Business Standard · tech CDS',bs,'2026-10-30','原文为约84bp；Alphabet段落未独立注明期限，保留未知，不能与其他公司直接排名。','~');
for(const o of additions)if(!seed.observations.some(v=>v.id===o.id))seed.observations.push(o);
seed.checkedAt=new Date().toISOString();seed.revision='research-expanded-'+Date.now();seed.checkNote='已核验6家公司的131条公开日线，并补充NVIDIA、CoreWeave、Meta、Broadcom与Alphabet的报道观测值。保留原来源和日期。';
await fs.writeFile('seed.json',JSON.stringify(seed,null,2)+'\n');
await fs.writeFile('import-batch.json',JSON.stringify({observations:additions},null,2)+'\n');
console.log(JSON.stringify({companies:seed.entities.length,daily:researched.length,dailyRecords:additions.filter(o=>o.quoteType==='daily_close').length,reports:additions.filter(o=>o.quoteType==='press_report').length,totalObservations:seed.observations.length}));
