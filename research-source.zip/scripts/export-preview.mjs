import {readFile,readdir,writeFile} from 'node:fs/promises';
const [html,analysis,ui,css,seed]=await Promise.all(['worker/ui.html','worker/analysis.js','worker/analysis-ui.js','worker/analysis.css','seed.json'].map(p=>readFile(p,'utf8')));
const logos=await readFile('cycle-public/company-logos.js','utf8');
const logoFiles=(await readdir('cycle-public')).filter(file=>/^logo-.+\.png$/.test(file));
const logoData=Object.fromEntries(await Promise.all(logoFiles.map(async file=>[
 file.slice(5,-4),'data:image/png;base64,'+(await readFile('cycle-public/'+file)).toString('base64')
])));
const chartColors=await readFile('cycle-public/chart-colors.js','utf8');
const data=JSON.parse(seed);data.persistence='ready';const literal=JSON.stringify(data).replaceAll('<','\\u003c');
const offlineHtml=html.replace('/* COMPANY_LOGOS */','const embeddedCompanyLogos='+JSON.stringify(logoData)+';\n'+logos).replace('/* SHARED_ANALYSIS */',analysis).replace('/* CHART_COLORS */',chartColors).replace('/* ANALYSIS_UI */',ui).replace('/* ANALYSIS_CSS */',css).replace("await fetch('/api/snapshot',{cache:'no-store'})",'({ok:true,json:async()=>('+literal+')})').replace('<body>','<body><div style="padding:12px 24px;background:#e7ece1;border-bottom:1px solid #c5cec0;font-size:13px">全部公司同图 · 离线交互预览。数据为已保存快照；本文件不自动更新，线上版本尚未发布。</div>');
await writeFile('/Users/miqiqimiaowu/Documents/Codex/2026-11-06/hui-c/outputs/cds-all-companies-preview.html',offlineHtml);
console.log('Saved self-contained interactive preview (no credentials).');
