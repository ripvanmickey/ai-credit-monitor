import base64,html,json,pathlib,re
root=pathlib.Path('.');public=root/'sox-public'
def literal(value):return json.dumps(value,ensure_ascii=False).replace('<','\\u003c')
cds=(root/'worker/ui.html').read_text()
for mark,file in [('/* SHARED_ANALYSIS */','worker/analysis.js'),('/* CHART_COLORS */','cycle-public/chart-colors.js'),('/* ANALYSIS_UI */','worker/analysis-ui.js'),('/* ANALYSIS_CSS */','worker/analysis.css')]:cds=cds.replace(mark,(root/file).read_text())
logos={p.stem[5:]:'data:image/png;base64,'+base64.b64encode(p.read_bytes()).decode() for p in (root/'cycle-public').glob('logo-*.png')}
cds=cds.replace('/* COMPANY_LOGOS */','const embeddedCompanyLogos='+literal(logos)+';\n'+(root/'cycle-public/company-logos.js').read_text())
seed=json.loads((root/'seed.json').read_text());seed['persistence']='ready'
cds=cds.replace("await fetch('/api/snapshot',{cache:'no-store'})",'({ok:true,json:async()=>('+literal(seed)+')})')
assets={p.relative_to(public).as_posix():base64.b64encode(p.read_bytes()).decode() for p in public.rglob('*') if p.is_file()}
sox=(public/'index.html').read_text()
def css(match):
 path=match.group(1).split('?')[0];s=(public/path).read_text()
 return '<style>'+re.sub(r"url\(['\"]?(fonts/[^)'\"]+)['\"]?\)",lambda m:'url(data:font/woff2;base64,'+assets[m.group(1)]+')',s)+'</style>'
sox=re.sub(r'<link rel="stylesheet" href="([^"]+)"[^>]*>',css,sox)
sox=re.sub(r'<link rel="preload"[^>]*>','',sox)
sox=re.sub(r'<script src="([^"]+)"[^>]*></script>',lambda m:'<script>'+(public/m.group(1).split('?')[0]).read_text().replace('</script','<\\/script')+'</script>',sox)
market=json.loads((root/'sox-market-seed.json').read_text());market['status']='saved';market['note']='离线预览，显示已保存的日线。'
mock='<script>const offlineAssets='+literal(assets)+';window.fetch=async function(input){let path=String(input).split("?")[0].replace(/^\\.\\//,"");if(path==="api/market")return new Response(JSON.stringify('+literal(market)+'),{headers:{"Content-Type":"application/json"}});if(offlineAssets[path])return new Response(Uint8Array.from(atob(offlineAssets[path]),c=>c.charCodeAt(0)));return new Response("Not found",{status:404});};</script>'
sox=sox.replace('</head>',mock+'</head>')
for key in list(assets):
 if key.endswith(('.csv','.md')):sox=sox.replace('href="'+key+'"','href="data:application/octet-stream;base64,'+assets[key]+'"')
for name,content in [('cds',cds),('sox',sox)]:
 content=re.sub(r'<div class="suite-bar">[\s\S]*?</div>','',content,count=1)
 navigation=(root/'worker/preview-navigation.js').read_text()
 content=content.replace('</body>','<script>'+navigation+'</script></body>')
 content=content.replace('href="/sox/#market"','href="#" onclick="parent.postMessage({suiteTab:\'sox\'},\'*\');return false"')
 if name=='cds':cds=content
 else:sox=content
page='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>半导体与算力信用观察 · 整合预览</title><style>*{box-sizing:border-box}body{margin:0;background:#f6f3ea;color:#173e35;font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif}.bar{padding:15px 22px;background:#183d36;color:#fff;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}.tabs{display:flex;gap:8px}.tabs button{font:inherit;padding:9px 14px;border:1px solid #c3cbbb;background:transparent;color:#fff;border-radius:3px;cursor:pointer}.tabs button[aria-selected=true]{background:#f6f3ea;color:#183d36}.notice{padding:9px 22px;border-bottom:1px solid #d1d8cc;font-size:11px}iframe{display:block;width:100%;height:calc(100vh - 105px);border:0}iframe[hidden]{display:none}</style><div class="bar"><strong>半导体 × 算力信用</strong><div class="tabs"><button data-tab="cds" aria-selected="true">CDS 信用监测</button><button data-tab="sox" aria-selected="false">SOX 周期研究</button></div><small>SOX行情：2026.11.06</small></div><div class="notice">本地整合预览 · 非线上版本，不自动更新。SOX已含11月6日周五日线，历史回测统计截至11月5日；CDS以各公司实际观测日为准。</div>'''
page+='<iframe id="cds" title="CDS信用监测" srcdoc="'+html.escape(cds,quote=True)+'"></iframe><iframe id="sox" title="SOX周期研究" hidden srcdoc="'+html.escape(sox,quote=True)+'"></iframe>'
page+='''<script>function showTab(id){if(!['sox','cds'].includes(id))return;for(const e of document.querySelectorAll('iframe'))e.hidden=e.id!==id;for(const b of document.querySelectorAll('[data-tab]'))b.setAttribute('aria-selected',b.dataset.tab===id);}document.querySelectorAll('[data-tab]').forEach(b=>b.onclick=()=>showTab(b.dataset.tab));addEventListener('message',e=>{if([...document.querySelectorAll('iframe')].some(f=>f.contentWindow===e.source))showTab(e.data?.suiteTab)});</script></html>'''
out=pathlib.Path('/Users/miqiqimiaowu/Documents/Codex/2026-11-06/hui-c/outputs/sox-cds-integrated-preview.html');out.write_text(page)
print('Exported self-contained integrated preview:',out.name,out.stat().st_size,'bytes')
