import http from 'node:http';
import {readFile} from 'node:fs/promises';
const source=await readFile('dist/server/index.js','utf8');
const {default:worker}=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
const seed=JSON.parse(await readFile('seed.json','utf8'));seed.persistence='ready';
const env={BUCKET:{get:async key=>key==='snapshot.json'?({text:async()=>JSON.stringify(seed)}):null}};
http.createServer(async(req,res)=>{const result=await worker.fetch(new Request('http://localhost:8788'+req.url),env);res.writeHead(result.status,Object.fromEntries(result.headers));res.end(Buffer.from(await result.arrayBuffer()));}).listen(8788,'127.0.0.1',()=>console.log('Local: http://localhost:8788'));
