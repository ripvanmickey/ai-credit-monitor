import http from 'node:http';
import { readFile, stat } from 'node:fs/promises';

const port = Number(process.env.PREVIEW_PORT ?? 8788);
const origin = 'http://localhost:' + port;
const bundle = new URL('../dist/server/index.js', import.meta.url);
const seedFile = new URL('../seed.json', import.meta.url);
let loaded;

async function loadBuild() {
  const { mtimeNs, ctimeNs } = await stat(bundle, { bigint: true });
  const revision = mtimeNs + '-' + ctimeNs;
  if (loaded?.revision !== revision) {
    const version = new URL(bundle);
    version.searchParams.set('revision', revision);
    const snapshot = readFile(seedFile, 'utf8').then(raw =>
      JSON.stringify({ ...JSON.parse(raw), persistence: 'ready' }),
    );
    const result = Promise.all([import(version.href), snapshot]).then(([module, data]) => ({
      worker: module.default,
      env: { BUCKET: { get: async key => key === 'snapshot.json' ? { text: async () => data } : null } },
    }));
    loaded = { revision, result };
  }
  return loaded.result;
}

await loadBuild();
http.createServer(async (req, res) => {
  try {
    const { worker, env } = await loadBuild();
    const result = await worker.fetch(new Request(origin + req.url, { method: req.method }), env);
    const headers = new Headers(result.headers);
    headers.set('Cache-Control', 'no-store');
    res.writeHead(result.status, Object.fromEntries(headers));
    res.end(Buffer.from(await result.arrayBuffer()));
  } catch (error) {
    console.error('Preview request failed:', error);
    res.writeHead(500);
    res.end('Preview build could not be loaded.');
  }
}).listen(port, '127.0.0.1', () => console.log('Local: ' + origin));
