import assert from 'node:assert/strict';
import {build} from 'esbuild';
import {mkdtemp,rm,readFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {pathToFileURL} from 'node:url';
const dir=await mkdtemp(join(tmpdir(),'chart-data-'));
try{await build({entryPoints:['ui/chart-data.ts'],outfile:join(dir,'chart.mjs'),platform:'node',format:'esm',bundle:true});const {prepareChartData}=await import(pathToFileURL(join(dir,'chart.mjs')));const payload={series:[{name:'Daily',color:'#dc2626',points:[{date:'2026-10-01',value:40},{date:'2026-10-02',value:42},{date:'2026-10-20',value:50}]},{name:'Report',color:'#737373',scatter:true,points:[{date:'2026-10-15',value:1100,operator:'>'}]}],unit:'bp',gapDays:7};const {dates,data,segments}=prepareChartData(payload);assert.equal(segments.length,3);assert(segments.find(s=>s.key==='s0p1'));assert(segments.find(s=>s.scatter));assert.deepEqual(dates,['2026-10-01','2026-10-02','2026-10-15','2026-10-20']);assert.equal(data[2].s0p0,undefined);assert.equal(data[2].s1p0,1100);assert.equal(payload.series[1].points[0].operator,'>');assert.equal(Object.values(data).filter(r=>r.s0p1===50).length,1);const html=await readFile('worker/ui.html','utf8');assert(!html.includes('data-trend='));assert(html.includes('data-detail='));console.log('PASS: actual dates/values, source gaps, scatter-only reports, bounds retained and details without redundant trend actions.');}finally{await rm(dir,{recursive:true,force:true});}
