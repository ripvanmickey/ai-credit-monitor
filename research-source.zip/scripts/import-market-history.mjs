import{readFile,writeFile,readdir}from'node:fs/promises';import{createHash}from'node:crypto';
const dir='../history-research',now=new Date().toISOString(),gpuSeed=JSON.parse(await readFile('gpu-price-seed.json')),bondSeed=JSON.parse(await readFile('bond-spread-seed.json')),errata=JSON.parse(await readFile(dir+'/errata.raw'));const gpu=[],bonds=[],treasury=[],sources=[];let excluded=0;
for(const file of (await readdir(dir)).filter(f=>/^hf-2026-.*\.json$/.test(f)).sort()){
 const text=await readFile(dir+'/'+file,'utf8'),snap=JSON.parse(text),archive='https://huggingface.co/datasets/gpurentalprices/gpu-rental-prices/resolve/main/data/snapshots/'+snap.date+'.json';
 sources.push({url:archive,date:snap.date,sha256:createHash('sha256').update(text).digest('hex')});
 for(const o of snap.offers||[]){
  if(!['aws','azure','gcp','runpod'].includes(o.provider)||!/^h100|^h200/.test(o.gpu)||!o.fetched_at?.startsWith(snap.date)||!Number.isFinite(o.usd_hr)||o.usd_hr<=0)continue;
  let kind=o.kind,drop=false;
  for(const e of errata.entries||[]){if(e.provider!==o.provider||snap.date<e.from||snap.date>e.to||(e.gpus!=='*'&&!e.gpus.includes(o.gpu))||(e.kinds&&!e.kinds.includes(kind))||(e.usd_hr!=null&&e.usd_hr!==o.usd_hr)||(e.snapshot_generated_at&&e.snapshot_generated_at!==snap.generated_at))continue;if(e.action==='exclude')drop=true;if(e.action==='reclassify-spot')kind='spot';if(e.action==='reclassify-marketplace')kind='marketplace';}
  if(drop){excluded++;continue;}
  const provider=o.provider.toUpperCase();const candidates=gpuSeed.observations.filter(s=>s.entityId===provider&&s.model.toLowerCase().includes(o.gpu.includes('h200')?'h200':'h100'));
  const match=candidates.find(s=>{
   if(o.provider==='runpod'){return o.gpu===(s.model.includes('PCIe')?'h100-pcie':'h100-sxm')&&((kind==='secure'&&s.billing==='secure_on_demand')||(kind==='community'&&s.billing==='community_from'));}
   return kind==='on-demand'&&s.billing==='on_demand'&&o.instance===s.sku&&o.region===s.region&&o.min_gpus===s.gpus&&o.gpu_count_reported===true;
  });if(!match)continue;
  if(['aws','azure'].includes(o.provider)){
   let raw;try{raw=JSON.parse(o.source_quote);}catch{continue;}
   if(o.provider==='aws'&&(raw['Instance Type']!==match.sku||raw['Operating System']!=='Linux'||Math.abs(Number(raw.price)/match.gpus-o.usd_hr)>1e-6))continue;
   if(o.provider==='azure'&&(raw.armSkuName!==match.sku||raw.armRegionName!==match.region||raw.productName.includes('Windows')||raw.meterName!=='ND96isrH100v5'||Math.abs(raw.retailPrice/match.gpus-o.usd_hr)>1e-6))continue;
  }
  gpu.push({...match,id:'hf:'+match.seriesKey+':'+snap.date,asOf:snap.date,publishedAt:o.fetched_at,observedAt:o.fetched_at,value:o.usd_hr,...(match.instanceHourly?{instanceHourly:o.usd_hr*match.gpus}:{}),archiveUrl:archive,archivePublisher:'GPU Rental Prices',archiveLicense:'CC BY 4.0',sourceQuote:o.source_quote,note:match.note+' 历史由GPU Rental Prices每日归档提供，保留原始采集时间与报价片段，已检查更正清单。'});
 }
}
const files={MSFT:'bond-MSFT.raw',AMZN:'bond-AMZN.raw',GOOGL:'bond-GOOGL.raw',ORCL:'bond-page.raw',CRWV:'bond-CRWV.raw'};
for(const b of bondSeed.bonds){const text=await readFile(dir+'/'+files[b.entityId],'utf8'),m=text.match(/var history = (\[[\s\S]*?\]);/);if(!m)throw Error('No public yield history: '+b.entityId);const data=JSON.parse(m[1]);const url='https://bondbyisin.com/bond/'+b.cusip;b.historySourceUrl=url;b.historySourceName='BondByIsin · 公开收益率历史';
 sources.push({url,sha256:createHash('sha256').update(text).digest('hex'),observedAt:now});
 for(const [date,yield_,price]of data){if(date<'2026-10-01'||date>now.slice(0,10)||!Number.isFinite(yield_)||yield_<=0)continue;bonds.push({id:'bondbyisin:'+b.id+':'+date,bondId:b.id,asOf:date,value:yield_,price,unit:'percent',currency:'USD',yieldType:'YTM',sourceUrl:url,observedAt:now,note:'公开页面免费收益率历史，按同一债券、同一来源计算；不是可成交报价，未调整赎回期权。'});}
}
const fredUrl='https://fred.stlouisfed.org/graph/fredgraph.csv?id=DGS5&cosd=2026-10-01&coed=2026-11-10';
for(const line of (await readFile(dir+'/fred.raw','utf8')).trim().split(/\r?\n/).slice(1)){const[date,value]=line.split(',');if(!value||!Number.isFinite(+value))continue;treasury.push({id:'fred-dgs5:'+date,asOf:date,value:+value,unit:'percent',sourceUrl:fredUrl,observedAt:now});}
await writeFile('bond-spread-seed.json',JSON.stringify(bondSeed,null,2)+'\n');
const out={schemaVersion:1,checkedAt:now,gpu,bonds,treasury,attribution:{name:'GPU Rental Prices',url:'https://gpurentalprices.com/data',license:'CC BY 4.0',licenseUrl:'https://creativecommons.org/licenses/by/4.0/'},errata:{url:'https://gpurentalprices.com/api/errata.json',checkedAt:now,updated:errata.updated,excluded},sources};
await writeFile('market-history-seed.json',JSON.stringify(out,null,2)+'\n');
console.log(JSON.stringify({gpu:gpu.length,bonds:bonds.length,treasury:treasury.length,byGPU:[...new Set(gpu.map(o=>o.seriesKey))].map(key=>{const rows=gpu.filter(o=>o.seriesKey===key);return{key,n:rows.length,from:rows[0].asOf,to:rows.at(-1).asOf,first:rows[0].value,last:rows.at(-1).value}}),byBond:bondSeed.bonds.map(b=>{const rows=bonds.filter(o=>o.bondId===b.id);return{id:b.entityId,n:rows.length,from:rows[0]?.asOf,to:rows.at(-1)?.asOf}})}));
