import {readFile,writeFile} from 'node:fs/promises';
const moduleText=await readFile('worker/gpu-prices.js','utf8');const {refreshGPUPrices}=await import('data:text/javascript;base64,'+Buffer.from('const GPU_PRICE_SEED={observations:[]};\n'+moduleText+'\nexport {refreshGPUPrices};').toString('base64'));
const result=await refreshGPUPrices({});await writeFile('gpu-price-seed.json',JSON.stringify(result,null,2)+'\n');console.log(JSON.stringify({checkedAt:result.checkedAt,status:result.status,observations:result.observations.length,checks:result.checks}));
