import assert from 'node:assert/strict';import {readFile} from 'node:fs/promises';import vm from 'node:vm';
let click,scrolls=0,prevented=0;const targets={market:{scrollIntoView:()=>scrolls++},analysis:{scrollIntoView:()=>scrolls++}};
vm.runInNewContext(await readFile('worker/preview-navigation.js','utf8'),{document:{addEventListener:(name,fn)=>click=fn,getElementById:id=>targets[id],documentElement:{scrollIntoView:()=>scrolls++}}});
function run(href,download=false){click({target:{closest:()=>({getAttribute:()=>href,hasAttribute:()=>download})},preventDefault:()=>prevented++});}
for(const href of ['#market','#analysis','index.html#market','./index.html#market','#'])run(href);
assert.equal(prevented,5);assert.equal(scrolls,5);
run('https://example.com/#market');run('report.md',true);assert.equal(prevented,5);
run('#%invalid');assert.equal(prevented,6);assert.equal(scrolls,5);
console.log('PASS: both modules keep fragment jumps inside their document; downloads/external links unaffected; malformed fragments do not navigate.');
