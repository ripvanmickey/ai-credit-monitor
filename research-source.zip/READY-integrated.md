# SOX + CDS + AI capital cycle

Root: CDS. /sox/: SOX analysis with preserved fixed backtest cutoff. /cycle/: AI capital cycle monitoring.

Model: worker/cycle-model.js. Initial verified quarterly facts: cycle-inputs.json. Optional immutable appended facts: snapshot.cycleObservations. All model computation uses actual disclosure dates and excludes future/stale inputs. Missing dimensions retain 0-2-point uncertainty each; no renormalization or probability claim. CDS is a disclosed credit proxy, not corporate bond OAS.

/api/update-instructions includes capitalCyclePlan for the existing three-hour automation. Never overwrite live R2 snapshots with local seed. No new automation or access changes.

Build: node scripts/build.mjs. Tests: node scripts/test.mjs; node scripts/test-cycle.mjs; node scripts/test-preview-navigation.mjs.

Financial baseline: NVIDIA issuer DSO45 ->60, Microsoft commercial RPO678 ->677 (billions), with primary-source links. GPU matched history and a second cloud RPO series remain missing; do not fill with interview numbers.
