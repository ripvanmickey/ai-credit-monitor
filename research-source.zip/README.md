# AI Credit Monitor

Owner-private research dashboard covering CDS, semiconductor backtests, and AI capital spending. Public daily tables and sourced media observations are saved to R2. See [UPDATE.md](UPDATE.md) for the collection workflow.

Install dependencies with `pnpm install`. Run `pnpm build` to build the site, `pnpm test` to run its tests, and `pnpm dev` to preview the built site.

For Sites publishing, use these commands to build and validate the artifact:

```json
[
  ["node", "scripts/build.mjs"],
  ["node", "scripts/validate-artifact.mjs"]
]
```

The build packages the shared UI and page assets into `dist/server/index.js`, a Worker ES module whose default export implements `fetch`. The hosting manifest is copied to `dist/.openai/hosting.json`. Edit the source in `worker/`, `ui/`, `cycle-public/`, or `sox-public/`.
