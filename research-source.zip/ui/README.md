Shared React UI uses shadcn/ui Radix Vega components (Button, Select, Input, Chart) with Lucide icons and Geist typography. The user-refined theme is Red / Neutral; preset origin and customizations are recorded in preset.json.

Research line and bar charts use the official ChartContainer and ChartTooltipContent with Recharts. chart-data.ts preserves actual dates and values, splits lines at source-specific gaps, and keeps reported observations as scatter-only data. SOX candles retain the specialized renderer with shared theme styles. Native form elements remain the data/event interface behind controlled component proxies.

Build: node scripts/build-ui.mjs. Component data and language regression checks: node scripts/test-component-data.mjs and node scripts/test-i18n.mjs.
