export type ChartPoint={date:string;value:number;publishedAt?:string;operator?:string};
export type ChartSeries={name:string;color:string;points:ChartPoint[];scatter?:boolean;dashed?:boolean;bar?:boolean};
export type ChartPayload={series:ChartSeries[];unit:string;gapDays:number;nearest?:boolean;log?:boolean;endLabels?:boolean};
export function prepareChartData(payload:ChartPayload){
 const dates=[...new Set(payload.series.flatMap(s=>s.points.map(p=>p.date)))].sort();
 const data=dates.map(date=>({t:Date.parse(date)} as Record<string,number>));
 const segments:{key:string;name:string;color:string;scatter?:boolean;dashed?:boolean;bar?:boolean;lastTime:number}[]=[];
 for(const [i,s]of payload.series.entries()){let segment=0,previous:number|undefined;for(const p of s.points){const time=Date.parse(p.date);if(previous!==undefined&&time-previous>payload.gapDays*86400000)segment++;const key='s'+i+'p'+segment;if(!segments.some(s=>s.key===key))segments.push({key,name:s.name,color:s.color,scatter:s.scatter,dashed:s.dashed,bar:s.bar,lastTime:Date.parse(s.points.at(-1)!.date)});data[dates.indexOf(p.date)][key]=p.value;previous=time;}}
 return {dates,data,segments};
}
