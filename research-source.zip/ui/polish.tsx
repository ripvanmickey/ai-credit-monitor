import * as React from 'react';
import {createRoot} from 'react-dom/client';
import {Input} from './components/input';
import {sourceText,sourceAttribute,translate} from './i18n';
const arrowPaths={up:'M7 17 17 7 M7 7h10v10',down:'M7 7l10 10 M7 17h10V7',flat:'M5 12h14'};

function changeIcon(direction: keyof typeof arrowPaths){
 const namespace='http://www.w3.org/2000/svg';
 const svg=document.createElementNS(namespace,'svg');
 svg.setAttribute('viewBox','0 0 24 24');
 svg.setAttribute('aria-hidden','true');
 svg.setAttribute('fill','none');
 svg.setAttribute('stroke','currentColor');
 svg.setAttribute('stroke-width','2');
 svg.setAttribute('stroke-linecap','round');
 svg.setAttribute('stroke-linejoin','round');
 const path=document.createElementNS(namespace,'path');
 path.setAttribute('d',arrowPaths[direction]);
 svg.append(path);
 return svg;
}
const changes=new Map<HTMLElement,string>();
const movement=/(↑|↓|→)\s*([+−-]?\s*\d[\d,]*(?:\.\d+)?(?:\s*(?:bp|%|days?\b|天|日))?)(?![\d-]|\.\d)/g;
function paintChange(host:HTMLElement,source:string){const text=translate(source);const fragment=document.createDocumentFragment();let end=0;movement.lastIndex=0;let m;while(m=movement.exec(text)){fragment.append(document.createTextNode(text.slice(end,m.index)));const value=document.createElement('span'),direction=m[1]==='↑'?'up':m[1]==='↓'?'down':'flat';value.className='ui-change is-'+direction;value.setAttribute('aria-label',m[2].trim()+' '+({up:translate('上涨'),down:translate('下跌'),flat:translate('持平')})[direction]);value.append(document.createTextNode(m[2].trim()));value.append(changeIcon(direction));fragment.append(value);end=m.index+m[0].length;}fragment.append(document.createTextNode(text.slice(end)));host.replaceChildren(fragment);}
function polishChanges(){const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);const nodes:Text[]=[];let n;while(n=walker.nextNode()){const node=n as Text;if(node.parentElement?.closest('script,style,code,pre,select,option,svg,textarea,[data-no-i18n]'))continue;movement.lastIndex=0;if(movement.test(node.data))nodes.push(node);}
 for(const node of nodes){const host=document.createElement('span');host.dataset.noI18n='';host.className='ui-change-text';const source=sourceText(node);changes.set(host,source);node.replaceWith(host);paintChange(host,source);}for(const host of changes.keys())if(!host.isConnected)changes.delete(host);}
function FormInput({native}:{native:HTMLInputElement}){const [,tick]=React.useReducer(n=>n+1,0);React.useEffect(()=>{const update=()=>tick();native.addEventListener('input',update);native.addEventListener('change',update);document.addEventListener('research-language-change',update);return()=>{native.removeEventListener('input',update);native.removeEventListener('change',update);document.removeEventListener('research-language-change',update);};},[native]);return <Input type={native.type} value={native.value} disabled={native.disabled} aria-label={translate(sourceAttribute(native,'aria-label')||sourceAttribute(native,'placeholder'))} placeholder={translate(sourceAttribute(native,'placeholder'))} onChange={e=>{native.value=e.target.value;native.dispatchEvent(new Event('input',{bubbles:true}));native.dispatchEvent(new Event('change',{bubbles:true}));tick();}}/>;}
export function startComponentPolish(){
 document.querySelectorAll<HTMLInputElement>('input[type=search],input[type=text]').forEach(native=>{if(native.dataset.slot||native.dataset.uiInput)return;native.dataset.uiInput='';const host=document.createElement('span');host.className='ui-input-host';host.dataset.noI18n='';native.insertAdjacentElement('afterend',host);native.style.display='none';createRoot(host).render(<FormInput native={native}/>);});
 let queued=false;const observer=new MutationObserver(()=>{if(queued)return;queued=true;queueMicrotask(()=>{polishChanges();queued=false;});});observer.observe(document.body,{subtree:true,childList:true,characterData:true});polishChanges();
 document.addEventListener('research-language-change',()=>{for(const [host,source]of changes)if(host.isConnected)paintChange(host,source);polishChanges();});
}
