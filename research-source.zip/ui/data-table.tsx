import { useLayoutEffect, useMemo, type CSSProperties } from 'react';
import { createRoot, type Root } from 'react-dom/client';
import {
  columnFilteringFeature, columnVisibilityFeature, createFilteredRowModel,
  createPaginatedRowModel, createSortedRowModel, rowPaginationFeature,
  rowSortingFeature, tableFeatures, useTable, type ColumnDef,
} from '@tanstack/react-table';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from './components/table';

const features = tableFeatures({
  columnFilteringFeature,
  columnVisibilityFeature,
  rowPaginationFeature,
  rowSortingFeature,
  filteredRowModel: createFilteredRowModel(),
  paginatedRowModel: createPaginatedRowModel(),
  sortedRowModel: createSortedRowModel(),
});

type Row = { id: string };
type Cell = { text: string; className?: string; style?: CSSProperties }
  | { html: string; className?: string; style?: CSSProperties };
type Column<T> = { id: string; title: string; sortLabel?: string; cell: (row: T) => Cell };
type TableConfig<T extends Row> = {
  bodyId: string;
  rows: T[];
  columns: Column<T>[];
  matches: (row: T) => boolean;
  sort: { id: string; desc: boolean };
  compare: (a: T, b: T, id: string, desc: boolean) => number;
  sortBy: (id: string) => void;
  empty: string;
  emptyClass?: string;
  pagination?: { pageIndex: number; pageSize: number };
  onView?: (count: number, pages: number) => void;
};

function DataTable<T extends Row>({ config }: { config: TableConfig<T> }) {
  const columns = useMemo<ColumnDef<typeof features, T>[]>(() => [
    ...config.columns.map(column => ({
      id: column.id,
      accessorFn: (row: T) => row.id,
      enableSorting: Boolean(column.sortLabel),
      sortFn: (a, b) => config.compare(a.original, b.original, column.id, config.sort.desc),
    } satisfies ColumnDef<typeof features, T>)),
    {
      id: '_matches',
      accessorFn: (row: T) => config.matches(row),
      filterFn: row => row.getValue('_matches') === true,
    },
    {
      id: '_default',
      accessorFn: (row: T) => row.id,
      sortFn: (a, b) => config.compare(a.original, b.original, '_default', false),
    },
  ], [config]);
  const table = useTable({
    features,
    data: config.rows,
    columns,
    getRowId: row => row.id,
    manualPagination: !config.pagination,
    autoResetPageIndex: false,
    state: {
      columnVisibility: { _matches: false, _default: false },
      columnFilters: [{ id: '_matches', value: true }],
      sorting: [config.sort],
      pagination: config.pagination ?? { pageIndex: 0, pageSize: 1 },
    },
  });
  const rows = table.getRowModel().rows;
  const filteredCount = table.getFilteredRowModel().rows.length;
  const pages = Math.max(1, table.getPageCount());
  useLayoutEffect(() => config.onView?.(filteredCount, pages), [config, filteredCount, pages]);

  return (
    <Table>
      <TableHeader>
        <TableRow>
          {config.columns.map(column => {
            const active = config.sort.id === column.id;
            return (
              <TableHead key={column.id} scope="col" data-source-label={column.title} aria-sort={active ? (config.sort.desc ? 'descending' : 'ascending') : undefined}>
                {column.sortLabel ? (
                  <button type="button" className="header-sort" aria-label={column.sortLabel} onClick={() => config.sortBy(column.id)}>
                    {column.title} <span className="sort-arrow" aria-hidden="true">{active ? (config.sort.desc ? '↓' : '↑') : '↕'}</span>
                  </button>
                ) : column.title}
              </TableHead>
            );
          })}
        </TableRow>
      </TableHeader>
      <TableBody id={config.bodyId}>
        {rows.length ? rows.map(row => (
          <TableRow key={row.id}>
            {config.columns.map(column => {
              const cell = column.cell(row.original);
              // Rich cells come from the dashboard's existing escaped formatters.
              return 'html' in cell
                ? <TableCell key={column.id} className={cell.className} style={cell.style} dangerouslySetInnerHTML={{ __html: cell.html }} />
                : <TableCell key={column.id} className={cell.className} style={cell.style}>{cell.text}</TableCell>;
            })}
          </TableRow>
        )) : (
          <TableRow><TableCell className={config.emptyClass ?? 'empty'} colSpan={config.columns.length}>{config.empty}</TableCell></TableRow>
        )}
      </TableBody>
    </Table>
  );
}

type TableHost = HTMLElement & { researchTableConfig?: TableConfig<Row> };
const roots = new WeakMap<TableHost, Root>();

export function startDataTables() {
  function render(host: TableHost) {
    const config = host.researchTableConfig;
    if (!config) return;
    let root = roots.get(host);
    if (!root) {
      root = createRoot(host);
      roots.set(host, root);
    }
    root.render(<DataTable config={config} />);
  }
  document.querySelectorAll<TableHost>('[data-research-table]').forEach(host => {
    host.addEventListener('research-table-update', () => render(host));
    render(host);
  });
}
