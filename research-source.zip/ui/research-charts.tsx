import * as React from 'react';
import {createRoot,Root} from 'react-dom/client';
import {Bar,LabelList,CartesianGrid,ComposedChart,Line,XAxis,YAxis} from 'recharts';
import {ChartContainer,ChartTooltip,ChartTooltipContent} from './components/chart';
import {translate} from './i18n';
import {prepareChartData,type ChartPoint as Point,type ChartPayload as Payload} from './chart-data';
function ResearchChart({payload}:{payload:Payload}){
 const [,tick]=React.useReducer(n=>n+1,0);React.useEffect(()=>{document.addEventListener('research-language-change',tick);return()=>document.removeEventListener('research-language-change',tick);},[]);
 const {dates,data,segments}=prepareChartData(payload);
 const config=Object.fromEntries(segments.map(s=>[s.key,{label:translate(s.name),color:s.color}]));
 const dateLabel=(t:number)=>new Date(t).toISOString().slice(0,10),unit=translate(payload.unit);
 if(!dates.length)return null;
 return <div data-no-i18n className="official-research-chart"><div className="ui-chart-unit">{unit}</div><ChartContainer config={config} className="h-[320px] w-full aspect-auto" style={{height:320,width:'100%'}}><ComposedChart data={data} margin={{left:12,right:payload.endLabels?115:24,top:16,bottom:8}} accessibilityLayer><CartesianGrid vertical={false} stroke="var(--border)"/><XAxis dataKey="t" type="number" scale="time" domain={['dataMin','dataMax']} tickFormatter={v=>dateLabel(v)} axisLine={false} tickLine={false} minTickGap={60} tickMargin={12}/><YAxis axisLine={false} tickLine={false} width={62} tickMargin={10} domain={payload.series.some(s=>s.bar)?[0,'auto']:['auto','auto']} scale={payload.log?'log':'auto'} tickFormatter={v=>Number(v).toLocaleString('en-US',{maximumFractionDigits:2})}/><ChartTooltip cursor={{stroke:'var(--border)',strokeDasharray:'4 4'}} content={(props:any)=>{if(!props.active)return null;const time=Number(props.label),entries=payload.series.flatMap((s,i)=>{const exact=s.points.find(p=>Date.parse(p.date)===time),point=payload.nearest?s.points.reduce<Point|undefined>((best,p)=>!best||Math.abs(Date.parse(p.date)-time)<Math.abs(Date.parse(best.date)-time)?p:best,undefined):exact;return point?[{name:translate(s.name),dataKey:'s'+i,value:point.value,color:s.color,payload:{...point}}]:[];});return <ChartTooltipContent className="ui-library-tooltip" active payload={entries as any} label={dateLabel(time)} labelFormatter={v=>String(v)} formatter={(value,name,item:any)=><div className="ui-chart-tooltip-row"><span style={{color:item.color}}>{String(name)}<small>{item.payload.date}{item.payload.publishedAt?' · '+translate('披露日期')+' '+item.payload.publishedAt:''}</small></span><strong>{item.payload.operator==='>'?'>':item.payload.operator==='~'?'≈':''}{Number(value).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2})} {unit}</strong></div>}/>;}}/>{segments.map(s=>s.bar?<Bar key={s.key} dataKey={s.key} fill={s.color} barSize={32} radius={4} isAnimationActive={false}/>:<Line key={s.key} dataKey={s.key} name={translate(s.name)} stroke={s.scatter?'transparent':s.color} strokeDasharray={s.dashed?'4 4':undefined} strokeWidth={2} type="linear" dot={{r:3,fill:s.color,strokeWidth:0}} activeDot={{r:5}} connectNulls isAnimationActive={false}>{payload.endLabels&&<LabelList dataKey={r=>r.t===s.lastTime&&r[s.key]!==undefined?translate(s.name):''} position="right" offset={8} style={{fontSize:10,fill:s.color}}/>}</Line>)}</ComposedChart></ChartContainer></div>;
}
type Distribution = {label:string;count:number;share:number}[];

function RecoveryDistribution({distribution}:{distribution:Distribution}){
 const [,refresh]=React.useReducer(n=>n+1,0);
 React.useEffect(()=>{
  document.addEventListener('research-language-change',refresh);
  return()=>document.removeEventListener('research-language-change',refresh);
 },[]);
 const data=distribution.map(({label,count,share})=>({
  range:translate(label),count,summary:`${translate(count+'次')} · ${share.toFixed(1)}%`,
 }));
 const config={count:{label:translate('样本数'),color:'var(--primary)'}};

 return <ChartContainer config={config} className="w-full aspect-auto" style={{height:260,width:'100%'}} data-no-i18n>
  <ComposedChart data={data} layout="vertical" margin={{top:0,right:112,bottom:0,left:0}} accessibilityLayer>
   <XAxis type="number" hide domain={[0,'dataMax']}/>
   <YAxis type="category" dataKey="range" width={82} axisLine={false} tickLine={false} tick={{fontSize:13}}/>
   <Bar dataKey="count" fill="var(--color-count)" radius={4} barSize={20} isAnimationActive={false}>
    <LabelList dataKey="summary" position="right" offset={8} fill="var(--muted-foreground)" style={{fontSize:13}}/>
   </Bar>
  </ComposedChart>
 </ChartContainer>;
}

type ChartTarget = HTMLElement & {
 researchChartPayload?: Payload | {distribution:Distribution} | null;
 renderResearchChart?: () => void;
};

export function startResearchCharts(){
 const targets = document.querySelectorAll<ChartTarget>(
  '#bars,#gpu-history,#credit-history,#orders-comparison-chart,#chip-dso-chart,#chart-svg,#order-history',
 );

 for(const target of targets){
  let host: HTMLDivElement | undefined;
  let root: Root | undefined;
  const render=()=>{
   const payload=target.researchChartPayload;
   if(!payload || (host && !target.contains(host))){
    root?.unmount();
    host?.remove();
    host=undefined;
    root=undefined;
   }
   if(!payload)return;

   if(target.id==='chart-svg'){
    const frame=document.querySelector<HTMLElement>('#chart-frame');
    if(frame){
     frame.onpointermove=null;
     frame.onpointerleave=null;
     frame.querySelector('#chart-tooltip')?.classList.add('hidden');
    }
   }

   if(!root){
    target.querySelectorAll(':scope > svg, :scope > [data-chart-fallback], :scope > .bar-row').forEach(svg=>svg.remove());
    host=document.createElement('div');
    target.insertBefore(host,target.querySelector(':scope > small'));
    root=createRoot(host);
   }
   root.render('distribution' in payload ? <RecoveryDistribution distribution={payload.distribution}/> : <ResearchChart payload={payload}/>);
  };
  target.renderResearchChart=render;
  render();
 }
}
