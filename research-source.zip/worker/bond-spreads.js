function isFredDgs5Url(value){try{const u=new URL(value);return u.protocol==='https:'&&u.hostname==='fred.stlouisfed.org'&&u.pathname==='/graph/fredgraph.csv'&&u.searchParams.get('id')==='DGS5';}catch{return false;}}
const BOND_TREASURY_SOURCE='https://www.federalreserve.gov/releases/h15/';
function parseTreasury5Y(text,at){
 const cols=[...text.matchAll(/<th\b[^>]*id="col(\d+)"[^>]*>([\s\S]*?)<\/th>/gi)].map(m=>({key:m[1],text:gpuPlain(m[2])}));
 const row=[...text.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)].find(m=>/<th\b[^>]*>[\s\S]*?>?5-year\s*<\/th>/.test(m[1])||/<th\b[^>]*>5-year<\/th>/.test(m[1]));
 if(!cols.length||!row)throw Error('H15 date/5-year row missing');
 const cells=[...row[1].matchAll(/<td\b[^>]*headers="[^"]*col(\d+)[^"]*"[^>]*>([\s\S]*?)<\/td>/gi)];
 return cells.map(m=>{const c=cols.find(c=>c.key===m[1]),value=Number(gpuPlain(m[2]));const date=c&&new Date(c.text+' UTC');if(!c||!Number.isFinite(+date)||!Number.isFinite(value)||value<=0)return null;const asOf=date.toISOString().slice(0,10);return {id:'ust5:'+asOf+':'+value,asOf,value,unit:'percent',sourceUrl:BOND_TREASURY_SOURCE,observedAt:at};}).filter(Boolean);
}
const BOND_FRED_SOURCE='https://fred.stlouisfed.org/graph/fredgraph.csv?id=DGS5&cosd=2026-10-01&coed=2026-11-10';
async function readBonds(env){
 const o=env.BUCKET?await env.BUCKET.get('bond-spreads.json'):null,p=o?JSON.parse(await o.text()):{...BOND_SEED,persistence:env.BUCKET?'seed':'unavailable'};
 return {...p,bonds:BOND_SEED.bonds,observations:mergeMarketHistory(MARKET_HISTORY_SEED.bonds,p.observations),treasury:mergeMarketHistory(MARKET_HISTORY_SEED.treasury,p.treasury)};
}
function validateBondUpdate(p,previous){
 if(!p||p.schemaVersion!==1||typeof p.revision!=='string'||!p.revision||!Number.isFinite(Date.parse(p.checkedAt))||Math.abs(Date.now()-Date.parse(p.checkedAt))>86400000||!Array.isArray(p.observations)||p.observations.length>5000||!Array.isArray(p.treasury)||p.treasury.length>2000)throw Error('invalid bond update');
 const ids=new Set();for(const o of p.observations){const b=BOND_SEED.bonds.find(b=>b.id===o.bondId);if(!b||!o.id||ids.has(o.id)||o.yieldType!=='YTM'||o.currency!=='USD'||o.unit!=='percent'||!Number.isFinite(o.value)||o.value<=0||o.value>100||!/^\d{4}-\d{2}-\d{2}$/.test(o.asOf)||!Number.isFinite(Date.parse(o.asOf))||Date.parse(o.asOf)>Date.now()||![b.sourceUrl,b.historySourceUrl].includes(o.sourceUrl)||!o.note||!Number.isFinite(Date.parse(o.observedAt)))throw Error('bond yield provenance/units invalid');ids.add(o.id);}
 const treasuryIds=new Set();for(const o of p.treasury){if(!o.id||treasuryIds.has(o.id)||!/^\d{4}-\d{2}-\d{2}$/.test(o.asOf)||!Number.isFinite(Date.parse(o.asOf))||Date.parse(o.asOf)>Date.now()||!Number.isFinite(o.value)||o.value<=0||o.value>30||!(o.sourceUrl===BOND_TREASURY_SOURCE||isFredDgs5Url(o.sourceUrl))||o.unit!=='percent')throw Error('invalid Treasury data');treasuryIds.add(o.id);}
 for(const key of ['observations','treasury'])for(const old of previous[key]||[]){const next=p[key].find(o=>o.id===old.id);if(!next||JSON.stringify(next)!==JSON.stringify(old))throw Error('bond/Treasury history immutable');}
}
function analyzeBonds(raw,now=new Date().toISOString()){
 const today=Date.parse(now),day=86400000;
 return {checkedAt:raw.checkedAt,revision:raw.revision,note:raw.note,treasury:raw.treasury,bonds:BOND_SEED.bonds.map(b=>{
  const available=(raw.observations||[]).filter(o=>o.bondId===b.id&&Date.parse(o.asOf)<=today);
  const historical=available.filter(o=>o.sourceUrl===b.historySourceUrl),activeSourceUrl=historical.length>=2?b.historySourceUrl:b.sourceUrl;
  const obs=available.filter(o=>o.sourceUrl===activeSourceUrl).sort((a,b)=>a.asOf.localeCompare(b.asOf)||a.observedAt.localeCompare(b.observedAt)).filter((o,i,a)=>i===a.length-1||o.asOf!==a[i+1].asOf);
  const rows=obs.map(o=>{const t=(raw.treasury||[]).filter(t=>t.asOf===o.asOf).at(-1),remainingYears=(Date.parse(b.maturity)-Date.parse(o.asOf))/(365.25*day);return {...o,treasury5Y:t?.value??null,spreadBp:t&&remainingYears>=4&&remainingYears<=6?(o.value-t.value)*100:null,remainingYears};});
  const matched=rows.filter(r=>r.spreadBp!==null),latestQuote=rows.at(-1),latestMatched=matched.at(-1),last=latestMatched||latestQuote;
  const change=k=>{const base=matched.at(-1-k);if(!base||!latestMatched||Date.parse(last.asOf)-Date.parse(base.asOf)>60*day)return null;return {from:base.asOf,to:last.asOf,bp:latestMatched.spreadBp-base.spreadBp,bondYieldBp:(latestMatched.value-base.value)*100,treasuryYieldBp:(latestMatched.treasury5Y-base.treasury5Y)*100};};
  const monthChange=marketMonthChange(matched,'spreadBp');
  const direction=monthChange?{...monthChange,bp:monthChange.delta}:(change(5)||change(1)),stale=!last||today-Date.parse(last.asOf)>7*day;
  const alternative=available.filter(o=>o.sourceUrl!==activeSourceUrl).sort((a,b)=>a.asOf.localeCompare(b.asOf)).at(-1);
  return {...b,activeSourceUrl,historySource:activeSourceUrl===b.historySourceUrl?'BondByIsin':'Atlantis Data Solutions',monthChange,alternative:alternative||null,latestQuote:latestQuote||null,rows,latest:last||null,matched:matched.length,stale,change1:change(1),change5:change(5),change20:change(20),direction:!direction?'样本不足':stale?'旧样本':direction.bp>1?'走阔':direction.bp< -1?'收窄':'大致平稳',directionWindow:direction?{from:direction.from,to:direction.to}:null};
 })};
}
function parsePublicBondHistory(text,bond,at){
 const match=text.match(/var history = (\[[\s\S]*?\]);/);if(!match)throw Error('Public yield history missing; no paid data requested');
 const data=JSON.parse(match[1]),cutoff=new Date(Date.parse(at)-45*86400000).toISOString().slice(0,10);
 return data.filter(r=>/^\d{4}-\d{2}-\d{2}$/.test(r[0])&&r[0]>=cutoff&&r[0]<=at.slice(0,10)&&Number.isFinite(r[1])&&r[1]>0&&r[1]<100).map(([asOf,value,price])=>({id:'bondbyisin:'+bond.id+':'+asOf,bondId:bond.id,asOf,value,price,unit:'percent',currency:'USD',yieldType:'YTM',sourceUrl:bond.historySourceUrl,observedAt:at,note:'公开页面免费收益率历史；同一债券、同一来源，非可成交报价，未调整赎回期权。'}));
}
async function refreshPublicBondHistory(env,at=new Date().toISOString()){
 const previous=await readBonds(env),observations=[...previous.observations],treasury=[...previous.treasury],checks=[];
 const treasuryUrl='https://fred.stlouisfed.org/graph/fredgraph.csv?'+new URLSearchParams({id:'DGS5',cosd:new Date(Date.parse(at)-60*86400000).toISOString().slice(0,10),coed:at.slice(0,10)});
 const jobs=[...BOND_SEED.bonds.map(b=>({id:b.entityId,url:b.historySourceUrl,bond:b})),{id:'FRED_DGS5',url:treasuryUrl},{id:'FED_H15',url:BOND_TREASURY_SOURCE}];
 const results=await Promise.allSettled(jobs.map(async job=>{const r=await fetch(job.url,{signal:AbortSignal.timeout(25000)});if(!r.ok)throw Error('HTTP '+r.status);const text=await r.text();if(job.bond)return parsePublicBondHistory(text,job.bond,at);if(job.id==='FED_H15')return parseTreasury5Y(text,at);
  if(!text.startsWith('observation_date,DGS5'))throw Error('FRED CSV schema changed');return text.trim().split(/\r?\n/).slice(1).flatMap(line=>{const[asOf,v]=line.split(',');if(!v||!/^\d{4}-\d{2}-\d{2}$/.test(asOf)||!Number.isFinite(+v)||+v<=0)return [];return [{id:'fred-dgs5:'+asOf,asOf,value:+v,unit:'percent',sourceUrl:treasuryUrl,observedAt:at}];});
 }));
 results.forEach((result,i)=>{const job=jobs[i];if(result.status==='rejected'){checks.push({id:job.id,status:'failed',at,note:String(result.reason.message).slice(0,150)});return;}checks.push({id:job.id,status:'ok',at,rows:result.value.length});
  const target=job.bond?observations:treasury;for(const row of result.value){const old=target.filter(o=>job.bond?o.bondId===row.bondId&&o.sourceUrl===row.sourceUrl&&o.asOf===row.asOf:(o.sourceUrl===row.sourceUrl||(isFredDgs5Url(o.sourceUrl)&&isFredDgs5Url(row.sourceUrl)))&&o.asOf===row.asOf).at(-1);if(old&&old.value===row.value)continue;if(target.some(o=>o.id===row.id))row.id+=':correction:'+at;target.push(row);}
 });
 const next={...previous,revision:'bond-history-'+Date.now(),checkedAt:at,observations,treasury,historyChecks:checks,note:'同源公开收益率历史与同日FRED名义5年美债；失败来源保留旧记录，缺失日不补值。'};
 validateBondUpdate(next,previous);await env.BUCKET.put('bond-spreads.json',JSON.stringify(next),{httpMetadata:{contentType:'application/json'}});return analyzeBonds(next,at);
}
