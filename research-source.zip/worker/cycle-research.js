// Evidence interpretation stays separate from executable quotes and causal claims.
function cycleResearch(cycle,gpu,bonds,cds,now=new Date().toISOString()){
 const fresh=d=>d&&Date.parse(d)<=Date.parse(now)&&Date.parse(now)-Date.parse(d)<=7*86400000;
 const qualified=gpu.series.filter(s=>s.trendEligible&&!s.pending&&!s.stale&&s.monthChange);
 const names=a=>[...new Set(a.map(s=>s.latest.entityId))];
 const up=qualified.filter(s=>s.monthChange.pct>=1),down=qualified.filter(s=>s.monthChange.pct<=-1),flat=qualified.filter(s=>Math.abs(s.monthChange.pct)<1);
 let priceTitle='租价证据不足，供需状态待确认',priceText='至少需要两家供应商具有同规格、同地区、同计费方式的近月历史。';
 if(names(qualified).length>=2){
  if(names(up).length>=2&&names(down).length===0){priceTitle='多家挂牌租价上涨，供需趋紧的线索增强';priceText='同规格公开租价出现跨供应商上涨，可能反映需求增加或供给收紧；两种原因尚不能区分。';}
  else if(names(down).length>=2&&names(up).length===0){priceTitle='多家挂牌租价下降，紧缺程度可能缓解';priceText='同规格公开租价出现跨供应商下降；也可能受到促销、竞争和新一代硬件替代影响，尚不能直接认定终端需求萎缩。';}
  else if(flat.length===qualified.length){priceTitle='挂牌租价持平，尚无涨价证据确认供需趋紧';priceText='可比云厂商的同规格近月挂牌租价未明显变化。价格黏性与企业折扣会掩盖成交变化，持平不能证明需求强劲，也不能证明需求疲弱。';}
  else{priceTitle='租价方向分化，尚无一致供需信号';priceText='供应商或型号之间的涨跌并不一致，先看各自规格、地区及可租容量，不能用最低价替代整体趋势。';}
 }
 const core=['MSFT','AMZN','GOOGL','ORCL'],entities=[...core,'CRWV'];
 const creditCompanies=entities.map(id=>{
  const bond=bonds.bonds.find(b=>b.entityId===id),s=cds.series.find(s=>s.entityId===id)||cds.tradeSeries.find(s=>s.entityId===id);
  const rows=(s?.rows||[]).filter(r=>Date.parse(r.asOf)<=Date.parse(now)),c=marketMonthChange(rows),cdsValid=!!(c&&c.n>=10&&fresh(c.to)),bondValid=!!(bond?.monthChange&&bond.monthChange.n>=10&&!bond.stale);
  const cdsDirection=cdsValid?(c.delta>1?'走阔':c.delta< -1?'收窄':'大致平稳'):'样本不足／过期';
  const bd=bondValid?(bond.monthChange.delta>1?'走阔':bond.monthChange.delta< -1?'收窄':'大致平稳'):'样本不足／过期';
  let conclusion='可比证据不足，暂不判断信用变化';
  if(cdsValid&&bondValid){conclusion=cdsDirection===bd?(bd==='走阔'?'两类信用溢价均扩大，融资风险定价上升':bd==='收窄'?'两类信用溢价均收窄，融资压力缓解':'两类信用溢价大致平稳'): 'CDS与公司债信号分化，尚不能确认同步变化';}
  else if(bondValid)conclusion=bd==='走阔'?'公司债风险溢价扩大；CDS近月证据待补':bd==='收窄'?'公司债风险溢价缩小；CDS近月证据待补':'公司债利差大致平稳；CDS近月证据待补';
  else if(cdsValid)conclusion=cdsDirection==='走阔'?'CDS风险溢价扩大；公司债近月证据待补':cdsDirection==='收窄'?'CDS风险溢价缩小；公司债近月证据待补':'CDS大致平稳；公司债近月证据待补';
  return {entityId:id,name:bond?.name||s?.name||id,core:core.includes(id),conclusion,bondValid,cdsValid,cds:s?{name:s.name,measurement:s.measurement,sourceUrl:s.sourceUrl,rows,latest:rows.at(-1)||null,monthChange:c,direction:cdsDirection}:null,bond};
 });
 const usable=creditCompanies.filter(c=>c.core&&(c.cdsValid||c.bondValid)),widened=usable.filter(c=>(c.cdsValid&&c.cds.monthChange.delta>1)||(c.bondValid&&c.bond.monthChange.delta>1)),narrowed=usable.filter(c=>(c.cdsValid&&c.cds.monthChange.delta< -1)||(c.bondValid&&c.bond.monthChange.delta< -1));
 const title=usable.length<3?'信用证据覆盖不足，暂不下整体结论':widened.length>=2?(narrowed.length?'信用溢价整体承压，部分信号仍分化':'多家核心云厂商信用溢价扩大，融资风险定价上升'):narrowed.length>=2?'多家核心云厂商信用溢价收窄，融资压力缓解':'信用溢价尚无一致方向';
 return {pricing:{title:priceTitle,text:priceText,qualified:qualified.length,providers:names(qualified).length,total:gpu.series.filter(s=>s.trendEligible).length,up:up.length,down:down.length,flat:flat.length,threshold:'展示方向以近月±1%为界；未超过视为大致持平。这与下跌≥10%／20%的周期压力阈值不同。',limits:'当前是公开挂牌价，不是实际成交价；确认算力紧缺还需可租容量、等候时间或利用率，确认需求强劲还需用量、收入与订单兑现。'},credit:{title,companies:creditCompanies,covered:usable.length,coreTotal:4,widened:widened.length,narrowed:narrowed.length,limits:'方向以近月变化超过±1bp区分扩大／缩小，其余视为大致平稳。利差扩大表示市场要求更高风险补偿，也受流动性、债券条款和交易供需影响；不是违约概率。公司债与CDS分别判断，不拼接曲线、不相加计分。CoreWeave单列为Neocloud旁证。',score:cycle.dimensions.find(d=>d.id==='credit')?.marketSignals||null}};
}
