let analysisData=null, activeEntity=new URLSearchParams(location.search).get('company')||'ORCL', chartMode=new URLSearchParams(location.search).get('company')?'line':'all';
const signed=(v,d=2)=>!Number.isFinite(v)?'—':(Number(v.toFixed(d))>0?'↑ +':Number(v.toFixed(d))<0?'↓ ':'→ ')+Number(v.toFixed(d)).toFixed(d);
function dailyStats(id){return analysisData?.series.find(s=>s.entityId===id)||analysisData?.tradeSeries.find(s=>s.entityId===id);}
function viewStats(id){return dailyStats(id)||analysisData?.reportSeries.find(s=>s.entityId===id);}
function displayObservation(id){return dailyStats(id)?.rows.at(-1)||observations(id).find(o=>!o.isIntradayExtreme);}
function missingReason(id){const a=analysisData?.coverage[id];return a?(a.disclosures?'已查披露，未取得合格5Y利差':'检索窗口内未找到合格5Y利差'):'暂无可核验数值';}
function mountAnalysis(){
 if($('#analysis'))return;
 const section=document.createElement('section');section.id='analysis';section.className='section';
 section.innerHTML=`<div class="sectionhead"><div><div class="eyebrow">01 / CDS OBSERVATIONS</div><h2>利差正在向谁集中？</h2></div><p>公开日线／DTCC成交中位数／报道点位，分口径查看</p></div>
 <div class="analysis-summary" id="comparison-summary"></div>
 <div class="panel"><div class="chart-toolbar"><label>观察公司 <select id="chart-company" aria-label="走势图公司"></select></label><div class="chart-switch" data-slot="tabs-list" data-variant="line" role="group" aria-label="图表类型"><button data-slot="tabs-trigger" data-chart="all" aria-pressed="false">全部公司同图</button><button data-slot="tabs-trigger" data-chart="line" aria-pressed="true">利差折线</button><button data-slot="tabs-trigger" data-chart="candle" aria-pressed="false">日K线</button><button data-slot="tabs-trigger" data-chart="compare" aria-pressed="false">同日起点＝100</button></div></div>
 <div class="chart-heading"><div><strong id="chart-title"></strong><p class="small" id="chart-subtitle"></p></div><span class="badge" id="chart-count"></span></div>
 <div id="chart-legend" class="chart-legend hidden"></div><div class="chart-frame" id="chart-frame"><div id="chart-svg"></div><div id="chart-tooltip" class="chart-tooltip hidden" role="status"></div></div>
 <div class="chart-metrics" id="chart-metrics"></div><details class="explanation hidden" id="daily-method"><summary>日线口径</summary><div class="explanation-content"><div class="tablenote" id="chart-method"></div></div></details><div id="report-ledger" class="report-ledger hidden"></div>
 <details class="explanation hidden" id="mixed-source-method"><summary>数据来源与比较口径</summary><div class="explanation-content"><div class="analysis-footnote">实线：公开日线；虚线及点：DTCC合格成交日中位数（约5年，非收盘价）；独立散点：五年期媒体报道。各条曲线不混入其他来源；同图不意味着币种、条款及取价时点完全可比，不据此直接排名违约风险。报道的≈、>等符号保留，期限未注明及日内极值不纳入同图。缺失不补值，间隔超过7天断线。</div></div></details></div>
 <div class="trend-section" id="trends"><div class="sectionhead"><div><div class="eyebrow">TREND / 各公司趋势</div><h2>信用保护成本，走阔还是收窄？</h2></div><p>CDS利差趋势 · 不等同于债券信用利差</p></div><div id="trend-summary" class="trend-summary"></div><div class="panel"><div class="trend-scroll"><table class="trend-table"><thead><tr><th>公司 / 数据口径</th><th>趋势方向</th><th>样本窗口</th><th>首尾变动</th><th>拟合斜率</th><th>拟合程度 R²</th></tr></thead><tbody id="trend-rows"></tbody></table></div><p class="analysis-footnote info-note">以各序列最新观测日为终点，取最近30个自然日内最多20个观测日，按实际日期做等权线性回归；至少5个观测日、跨度至少7天。拟合首尾涨幅超过+5%为走阔，低于−5%为收窄，其余为大致平稳；这是展示阈值，不是显著性检验或预测。斜率单位为bp／自然周；R²越接近1表示样本越贴近直线，不代表预测准确率。无交易日不补值，报价日线与成交中位数不混算；各公司窗口可能不同，不按斜率直接排名。超过7天未更新的序列标为旧样本。</p></div></div>`;
 $('#watchlist').before(section);
 $('#chart-company').onchange=e=>{activeEntity=e.target.value;renderChart();};
 section.querySelectorAll('[data-chart]').forEach(b=>b.onclick=()=>{chartMode=b.dataset.chart;section.querySelectorAll('[data-chart]').forEach(x=>x.setAttribute('aria-pressed',String(x===b)));renderChart();});
}
function renderAnalysis(){
 analysisData=analyzeSnapshot(data);mountAnalysis();const a=analysisData,c=a.common;
 const views=data.entities.map(e=>viewStats(e.id)).filter(Boolean);
 $('#chart-company').innerHTML=views.map(s=>'<option value="'+esc(s.entityId)+'">'+esc(s.name)+' · '+(s.measurement==='daily_close'?'日线':s.measurement==='trade_median'?'成交中位数':'报道点位')+'</option>').join('');
 if(!views.some(s=>s.entityId===activeEntity))activeEntity=views[0]?.entityId;$('#chart-company').value=activeEntity;
 if(c){const max=[...c.pairs].sort((a,b)=>b.pct-a.pct)[0],min=[...c.pairs].sort((a,b)=>a.pct-b.pct)[0];$('#comparison-summary').innerHTML='<div><label>共同日期样本</label><strong>'+esc(c.from)+' — '+esc(c.to)+'</strong><span>'+c.n+'个共同报价日 · '+c.companies+'家公司</span></div><div><label>利差走阔的公司</label><strong>'+c.widened+' / '+c.companies+'</strong><span>共同区间首尾比较</span></div><div><label>区间扩大最多</label><strong>'+esc(max.name)+' '+signed(max.pct,1)+'%</strong><span>'+signed(max.bp)+' bp</span></div><div><label>区间变动最小</label><strong>'+esc(min.name)+' '+signed(min.pct,1)+'%</strong><span>'+signed(min.bp)+' bp</span></div>';}
 else $('#comparison-summary').textContent='暂无足够的共同日期样本。';
 renderTrends();renderChart();
}
function renderTrends(){
 const trends=analysisData.trends||[],valid=trends.filter(t=>t.status==='ok');
 $('#trend-summary').textContent='可计算 '+valid.length+' / '+trends.length+' 家 · 走阔 '+valid.filter(t=>t.direction==='走阔').length+' 家 · 收窄 '+valid.filter(t=>t.direction==='收窄').length+' 家 · 大致平稳 '+valid.filter(t=>t.direction==='大致平稳').length+' 家（各自样本窗口）';
 $('#trend-rows').innerHTML=trends.map(t=>{const ok=t.status==='ok',stale=t.to&&(Date.now()-Date.parse(t.to)>7*86400000),kind=t.measurement==='daily_close'?'公开日线':t.measurement==='trade_median'?'DTCC成交中位数':t.status==='reports'?'独立报道':'暂无连续数据';return '<tr><td><div class="order-company-identity">'+companyLogo(t.entityId)+'<div><strong>'+esc(t.name)+'</strong><small>'+esc(kind)+'</small></div></div></td><td><strong class="'+(t.direction==='走阔'?'widen':t.direction==='收窄'?'narrow':'')+'">'+esc(ok?t.direction:t.status==='reports'?'报道点，不判断':'样本不足')+'</strong>'+(stale?'<small>旧样本</small>':'')+'</td><td>'+(t.from?esc(t.from)+' → '+esc(t.to)+'<small>N='+t.n+' · '+t.days+'个自然日</small>':'—')+'</td><td>'+(ok?signed(t.changeBp)+' bp<small>'+signed(t.changePct,1)+'%</small>':'—')+'</td><td>'+(ok?signed(t.weeklyBp)+' bp／周':'—')+'</td><td>'+(ok?(t.rSquared==null?'不适用（常数序列）':t.rSquared.toFixed(2)):'<small>'+esc(t.reason)+'</small>')+'</td></tr>';}).join('');
}
function renderChart(){
 if(chartMode==='all'){renderAllCompanies();return;}
 $('#daily-method').classList.add('hidden');
 $('#mixed-source-method').classList.add('hidden');
 const host=$('#chart-svg');
 host.researchChartPayload=null;
 const s=viewStats(activeEntity);if(!s){host.renderResearchChart?.();host.innerHTML='<p class="empty">暂无可分析的观测记录。</p>';return;}
 const report=s.measurement==='press_report',trade=s.measurement==='trade_median';if(chartMode==='candle'&&(report||trade))chartMode='line';const compare=chartMode==='compare';
 document.querySelector('[data-chart="candle"]').disabled=report||trade;
 document.querySelectorAll('[data-chart]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.chart===chartMode)));
 const rows=s.rows,c=analysisData.common;$('#chart-company').disabled=compare;
 $('#chart-title').textContent=compare?'同日起点设为100，比较利差变化':s.name+' · '+(report?quote(rows.at(-1)):s.latest.toFixed(3))+' bp';
 $('#chart-subtitle').textContent=compare&&c?c.from+' 至 '+c.to+' · 仅比较6家同源日线':s.from+' 至 '+s.to+' · '+s.sourceName+(trade?' · 约5年期（剩余4.4—5.6年）':report?' · 期限按各条记录':' · '+s.instrument);
 $('#chart-count').textContent=compare&&c?c.n+'个共同报价日':s.n+(report?'条独立报道':trade?'个成交观测日':'条日线');
 $('#report-ledger').classList.toggle('hidden',!report||compare);$('#report-ledger').innerHTML=report&&!compare?'<h3>已核验报道点位</h3>'+[...rows].reverse().map(o=>'<div class="report-row"><time>'+esc(o.asOf)+'</time><strong>'+esc(quote(o))+' bp'+(o.isIntradayExtreme?' · 日内高点':'')+'</strong><span>'+esc(o.tenor||'期限未注明')+'</span><a href="'+safeUrl(o.sourceUrl)+'" target="_blank" rel="noopener">'+esc(o.sourceTitle)+' ↗</a></div>').join(''):'';
 $('#chart-legend').classList.toggle('hidden',!compare);$('#chart-legend').innerHTML=compare&&c?c.pairs.map(p=>'<span><i style="background:'+companyChartColor(p.entityId)+'"></i>'+esc(p.name)+' '+signed(p.pct,1)+'%</span>').join(''):'';
 $('#chart-metrics').innerHTML=compare&&c?'<div><label>篮子区间变动中位数</label><strong>'+signed(c.medianPct,1)+'%</strong></div><div><label>比较口径</label><strong>'+c.companies+'家公司 · 同日起点</strong></div><div><label>有效日期</label><strong>'+c.n+'个共同报价日</strong></div>':(report?[
 ['最新报道',quote(rows.at(-1))+' bp'],['观测日期',s.to],['近5／20日变动','缺少连续序列'],['区间分位','报道点位不计算']
 ]:[
  ['近1'+(trade?'成交观测日':'报价日')+'变动',s.day?signed(s.day.bp)+' bp':'窗口不足'],['近5'+(trade?'成交观测日':'报价日')+'变动',s.change5?signed(s.change5.bp)+' bp':'窗口不足'],['近20'+(trade?'成交观测日':'报价日')+'变动',s.change20?signed(s.change20.bp)+' bp':'窗口不足／过疏'],['已收集区间分位',s.percentile==null?'不足20个观测日':s.percentile.toFixed(1)+'%']
 ]).map(([label,value])=>'<div><label>'+label+'</label><strong>'+esc(value)+'</strong></div>').join('');
 const showDailyMethod=compare?Boolean(c):s.measurement==='daily_close';
 $('#daily-method').classList.toggle('hidden',!showDailyMethod);
 if(showDailyMethod){
  $('#chart-method').innerHTML=compare
   ? '基准100代表共同起点；150表示利差较起点扩大50%。本图不混入DTCC成交中位数或媒体点位，不据此推断违约概率。'
   : esc(s.from+' 至 '+s.to+'，共'+s.n+'条日线。分位采用同值中位秩；缺失不补零、不插值。')
     +(chartMode==='candle'?' <span>红色表示收盘利差不低于开盘，灰色表示收盘利差低于开盘。</span>':'')
     +' <a href="'+safeUrl(s.sourceUrl)+'" target="_blank" rel="noopener">原始历史表 ↗</a>';
 }
 if(chartMode!=='candle'){
  host.researchChartPayload={series:compare&&c?c.pairs.map(p=>({name:p.name,color:companyChartColor(p.entityId),points:p.points})): [{name:s.name,color:'#dc2626',points:rows.map(r=>({date:r.asOf,value:r.value,operator:r.operator})),scatter:report,dashed:trade}],unit:compare?'指数':'bp',gapDays:7};
  if(host.renderResearchChart){host.querySelector(':scope > .empty')?.remove();host.renderResearchChart();return;}
 }else host.renderResearchChart?.();
 const W=Math.max(320,Math.min(1000,$('#chart-frame').clientWidth-32)),H=W<600?260:330,L=W<600?44:66,R=W<600?88:112,T=20,B=40,plotW=W-L-R,plotH=H-T-B;
 const dates=compare&&c?c.pairs[0].points.map(p=>p.date):rows.map(r=>r.asOf);
 const from=Date.parse(dates[0]),to=Date.parse(dates.at(-1)),x=d=>L+(Date.parse(d)-from)/(to-from||1)*plotW;
 const values=compare&&c?c.pairs.flatMap(p=>p.points.map(x=>x.value)):rows.flatMap(r=>chartMode==='candle'?[r.high??r.value,r.low??r.value]:[r.value]);
 let lo=Math.min(...values),hi=Math.max(...values);const pad=(hi-lo||Math.abs(hi)*.05||1)*.14;lo=Math.max(0,lo-pad);hi+=pad;const y=v=>T+(hi-v)/(hi-lo)*plotH;
 let svg='<svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="'+esc(compare?'CDS共同区间相对变化':s.name+' CDS走势图')+'">';
 for(let i=0;i<5;i++){const value=lo+(hi-lo)*i/4,yy=y(value);svg+='<line x1="'+L+'" x2="'+(W-R)+'" y1="'+yy+'" y2="'+yy+'" stroke="#dfdfdf"/><text x="'+(L-10)+'" y="'+(yy+4)+'" text-anchor="end">'+value.toFixed(1)+'</text>';}
 const ticks=W<600?[0,Math.floor((dates.length-1)/2),dates.length-1]:[0,Math.floor((dates.length-1)/3),Math.floor((dates.length-1)*2/3),dates.length-1];for(const i of [...new Set(ticks)])svg+='<text x="'+x(dates[i])+'" y="'+(H-13)+'" text-anchor="'+(i===0?'start':i===dates.length-1?'end':'middle')+'">'+(W<600?dates[i].slice(5):dates[i])+'</text>';
 function linePath(points){let prev=null;return points.map(p=>{const gap=prev&&(Date.parse(p.date)-Date.parse(prev))/86400000>7;const cmd=!prev||gap?'M':'L';prev=p.date;return cmd+x(p.date).toFixed(2)+','+y(p.value).toFixed(2)}).join(' ');}
 if(compare&&c){for(const p of c.pairs)svg+='<path d="'+linePath(p.points)+'" fill="none" stroke="'+companyChartColor(p.entityId)+'" stroke-width="2.5"/>';}
 else if(chartMode==='candle'){
  const width=Math.min(20,plotW/Math.max(rows.length,1)*.55);for(const r of rows){const open=r.open??r.value,high=r.high??r.value,low=r.low??r.value,col=r.value>=open?'#dc2626':'#737373';svg+='<line x1="'+x(r.asOf)+'" x2="'+x(r.asOf)+'" y1="'+y(high)+'" y2="'+y(low)+'" stroke="'+col+'" stroke-width="1.5"/><rect x="'+(x(r.asOf)-width/2)+'" y="'+Math.min(y(open),y(r.value))+'" width="'+width+'" height="'+Math.max(1.4,Math.abs(y(open)-y(r.value)))+'" fill="'+col+'"/>';}
 }else if(report){svg+=rows.map(r=>'<circle cx="'+x(r.asOf)+'" cy="'+y(r.value)+'" r="5" fill="'+(r.operator==='='?'#dc2626':'#fcfbf7')+'" stroke="#dc2626" stroke-width="2"/><text x="'+x(r.asOf)+'" y="'+(y(r.value)-10)+'" text-anchor="'+(r.asOf===dates[0]?'start':r.asOf===dates.at(-1)?'end':'middle')+'">'+esc(quote(r))+'</text>').join('');}
 else svg+='<path d="'+linePath(rows.map(r=>({date:r.asOf,value:r.value})))+'" fill="none" stroke="#dc2626" stroke-width="2.6"/>'+rows.map(r=>'<circle cx="'+x(r.asOf)+'" cy="'+y(r.value)+'" r="2.5" fill="#dc2626"/>').join('');
 const endLabels=(compare&&c?c.pairs.map(p=>({name:p.name,color:companyChartColor(p.entityId),value:p.points.at(-1).value})): [{name:s.name,color:report?'#dc2626':'#dc2626',value:rows.at(-1).value}]).map(p=>({...p,target:y(p.value)})).sort((a,b)=>a.target-b.target);
 const labelGap=18;let nextY=T+8;
 for(const p of endLabels){p.labelY=Math.max(p.target,nextY);nextY=p.labelY+labelGap;}
 let lastY=H-B-6;for(let i=endLabels.length-1;i>=0;i--){endLabels[i].labelY=Math.min(endLabels[i].labelY,lastY);lastY=endLabels[i].labelY-labelGap;}
 for(const p of endLabels){svg+='<path d="M'+(W-R)+','+p.target+' L'+(W-R+9)+','+p.labelY+' H'+(W-R+14)+'" fill="none" stroke="'+p.color+'" stroke-width="1.2"/><text class="chart-end-label" x="'+(W-R+18)+'" y="'+(p.labelY+4)+'" style="fill:'+p.color+';font-size:'+(W<600?10:11)+'px;font-weight:600">'+esc(p.name)+'</text>';}
 svg+='<line id="chart-crosshair" x1="0" x2="0" y1="'+T+'" y2="'+(H-B)+'" stroke="#737373" stroke-dasharray="3 3" visibility="hidden"/></svg>';$('#chart-svg').innerHTML=svg;
 const frame=$('#chart-frame'),tip=$('#chart-tooltip'),svgEl=frame.querySelector('svg'),cross=frame.querySelector('#chart-crosshair');
 function hover(clientX,clientY){const box=svgEl.getBoundingClientRect(),px=(clientX-box.left)/box.width*W;if(px<L||px>W-R){tip.classList.add('hidden');cross.setAttribute('visibility','hidden');return;}let index=0;for(let i=1;i<dates.length;i++)if(Math.abs(x(dates[i])-px)<Math.abs(x(dates[index])-px))index=i;
  cross.setAttribute('x1',x(dates[index]));cross.setAttribute('x2',x(dates[index]));cross.setAttribute('visibility','visible');
  if(compare&&c)tip.innerHTML='<strong>'+dates[index]+'</strong>'+c.pairs.map(p=>'<div><span style="color:'+companyChartColor(p.entityId)+'">'+esc(p.name)+'</span><b>'+p.points[index].value.toFixed(2)+'</b></div>').join('');
  else{const r=rows[index],previous=rows[index-1],delta=previous?r.value-previous.value:null,pct=previous&&previous.value?100*(r.value/previous.value-1):null;tip.innerHTML=report?'<strong>'+esc(r.asOf)+' · '+esc(s.name)+'</strong><div>报道值 <b>'+esc(quote(r))+' bp</b></div><div>期限 <b>'+esc(r.tenor||'未注明')+'</b></div><p>'+esc(r.sourceTitle)+'</p>':trade?'<strong>'+esc(r.asOf)+' · '+esc(s.name)+'</strong><div>成交中位数 <b>'+r.value.toFixed(3)+' bp</b></div><div>符合条件成交 <b>'+r.tradeCount+'笔</b></div><div>可用成交范围 <b>'+r.tradeLow.toFixed(2)+'—'+r.tradeHigh.toFixed(2)+'</b></div><div>较上一成交观测日 <b>'+signed(delta)+' bp</b></div>':'<strong>'+esc(r.asOf)+' · '+esc(s.name)+'</strong><div>开盘 <b>'+Number(r.open??r.value).toFixed(3)+'</b></div><div>最高 <b>'+Number(r.high??r.value).toFixed(3)+'</b></div><div>最低 <b>'+Number(r.low??r.value).toFixed(3)+'</b></div><div>收盘 <b>'+r.value.toFixed(3)+' bp</b></div><div>较前一报价日 <b>'+signed(delta)+' bp</b></div><div>涨跌幅 <b>'+signed(pct)+'%</b></div>';}
  const rect=frame.getBoundingClientRect();tip.classList.remove('hidden');tip.style.left=Math.max(8,Math.min(clientX-rect.left+14,rect.width-tip.offsetWidth-8))+'px';tip.style.top=Math.max(6,Math.min(clientY-rect.top-35,rect.height-tip.offsetHeight-8))+'px';
 }
 frame.onpointermove=e=>hover(e.clientX,e.clientY);frame.onpointerleave=()=>{tip.classList.add('hidden');cross.setAttribute('visibility','hidden');};

}
window.addEventListener('resize',()=>{if(analysisData&&(chartMode==='candle'||!$('#chart-svg').renderResearchChart))renderChart();});

let allCompanyHidden=new Set(),allCompanyLog=true;
function renderAllCompanies(){
 const list=allCompanySeries(data,analysisData).map(s=>({...s,color:companyChartColor(s.entityId)})),shown=list.filter(s=>!allCompanyHidden.has(s.entityId));
 $('#chart-company').disabled=true;
 document.querySelectorAll('[data-chart]').forEach(b=>b.setAttribute('aria-pressed',String(b.dataset.chart==='all')));
 $('#report-ledger').classList.add('hidden');$('#chart-legend').classList.remove('hidden');
 $('#chart-title').textContent='全部公司 · CDS利差（bp）';
 $('#chart-subtitle').textContent='同一时间轴、原始基点值 · '+(allCompanyLog?'对数纵轴，等距代表相同比例变化':'线性纵轴，等距代表相同bp变化');
 $('#chart-count').textContent=shown.length+' / '+list.length+'家公司';
 const type=s=>s.measurement==='daily_close'?'日线':s.measurement==='trade_median'?'成交中位数':'5Y报道散点';
 $('#chart-legend').innerHTML='<div class="all-chart-controls"><label><input type="checkbox" id="all-log" '+(allCompanyLog?'checked':'')+'> 对数纵轴</label><button id="all-show">显示全部</button><span>点击公司隐藏／显示；下方可悬停查原始点位</span></div><div class="all-company-legend">'+list.map(s=>'<button type="button" data-all-company="'+esc(s.entityId)+'" aria-pressed="'+!allCompanyHidden.has(s.entityId)+'" style="--company-color:'+s.color+'"><i></i><strong>'+esc(s.name)+'</strong><small>'+type(s)+'</small></button>').join('')+'</div>';
 $('#all-log').onchange=e=>{allCompanyLog=e.target.checked;renderAllCompanies();};$('#all-show').onclick=()=>{allCompanyHidden.clear();renderAllCompanies();};
 document.querySelectorAll('[data-all-company]').forEach(b=>b.onclick=()=>{const id=b.dataset.allCompany;allCompanyHidden.has(id)?allCompanyHidden.delete(id):allCompanyHidden.add(id);renderAllCompanies();});
 $('#daily-method').classList.add('hidden');
 $('#mixed-source-method').classList.toggle('hidden',new Set(shown.map(s=>s.measurement)).size<2);
 const missing=data.entities.filter(e=>!list.some(s=>s.entityId===e.id));
 $('#chart-metrics').innerHTML='<div><label>连续观测序列</label><strong>'+shown.filter(s=>s.measurement!=='press_report').length+'家</strong></div><div><label>报道点位</label><strong>'+shown.filter(s=>s.measurement==='press_report').length+'家 · 不连线</strong></div><div><label>未取得合格数据</label><strong>'+missing.length+'家</strong><small>'+missing.map(e=>esc(e.name)).join('、')+'</small></div>';
 const frame=$('#chart-frame'),tip=$('#chart-tooltip');tip.classList.add('hidden');frame.onpointermove=null;frame.onpointerleave=null;
 const host=$('#chart-svg');
 if(!shown.length){
  host.researchChartPayload=null;
  host.renderResearchChart?.();
  host.innerHTML='<p class="empty">所有公司已隐藏，点击“显示全部”恢复。</p>';
  return;
 }
 if(!host.researchChartPayload)host.querySelector(':scope > .empty')?.remove();
 host.researchChartPayload={series:shown.map(s=>({name:s.name,color:s.color,points:s.rows.map(r=>({date:r.asOf,value:r.value,operator:r.operator})),scatter:s.measurement==='press_report',dashed:s.measurement==='trade_median'})),unit:'bp',gapDays:7,log:allCompanyLog,endLabels:true};
 if(host.renderResearchChart){host.renderResearchChart();return;}
 const W=Math.max(320,Math.min(1100,frame.clientWidth-32)),H=W<600?440:420,L=W<600?46:66,R=W<600?94:130,T=26,B=35;
 const dates=[...new Set(shown.flatMap(s=>s.rows.map(r=>r.asOf)))].sort(),from=Date.parse(dates[0]),to=Date.parse(dates.at(-1));
 const x=d=>L+(Date.parse(d)-from)/(to-from||1)*(W-L-R),values=shown.flatMap(s=>s.rows.map(r=>r.value));
 const transform=v=>allCompanyLog?Math.log(v):v,low=transform(Math.min(...values)),high=transform(Math.max(...values)),pad=(high-low||.1)*.08,lo=allCompanyLog?low-pad:Math.max(0,low-pad),hi=high+pad;
 const y=v=>T+(hi-transform(v))/(hi-lo)*(H-T-B),kind=s=>s.measurement==='press_report';
 let svg='<svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="全部公司CDS利差同图，'+(allCompanyLog?'对数':'线性')+'纵轴">';
 for(let i=0;i<6;i++){const tv=lo+(hi-lo)*i/5,value=allCompanyLog?Math.exp(tv):tv,yy=y(value);svg+='<line x1="'+L+'" x2="'+(W-R)+'" y1="'+yy+'" y2="'+yy+'" stroke="#dfdfdf"/><text x="'+(L-8)+'" y="'+(yy+4)+'" text-anchor="end">'+value.toFixed(0)+'</text>';}
 svg+='<text x="'+L+'" y="14">bp'+(allCompanyLog?' · 对数轴':'')+'</text>';
 for(const i of [0,Math.floor((dates.length-1)/2),dates.length-1])svg+='<text x="'+x(dates[i])+'" y="'+(H-10)+'" text-anchor="'+(i===0?'start':i===dates.length-1?'end':'middle')+'">'+(W<600?dates[i].slice(5):dates[i])+'</text>';
 for(const s of shown){
  if(!kind(s)){let previous=null;const path=s.rows.map(r=>{const move=!previous||Date.parse(r.asOf)-Date.parse(previous)>7*86400000;previous=r.asOf;return (move?'M':'L')+x(r.asOf)+','+y(r.value);}).join(' ');svg+='<path class="all-series-line" data-entity="'+esc(s.entityId)+'" d="'+path+'" stroke="'+s.color+'" fill="none" stroke-width="2" '+(s.measurement==='trade_median'?'stroke-dasharray="4 3"':'')+'/>';}
  for(const r of s.rows)svg+='<circle class="all-series-point" data-entity="'+esc(s.entityId)+'" cx="'+x(r.asOf)+'" cy="'+y(r.value)+'" r="'+(kind(s)?4.5:2)+'" fill="'+(kind(s)&&r.operator!=='='?'#fcfbf7':s.color)+'" stroke="'+s.color+'" stroke-width="1.5"><title>'+esc(s.name+' · '+r.asOf+' · '+quote(r)+' bp · '+type(s))+'</title></circle>';
 }
 const labels=shown.map(s=>({...s,last:s.rows.at(-1),target:y(s.rows.at(-1).value)})).sort((a,b)=>a.target-b.target);let next=T+4;
 for(const s of labels){s.ly=Math.max(s.target,next);next=s.ly+18;}let bottom=H-B-6;for(let i=labels.length-1;i>=0;i--){labels[i].ly=Math.min(labels[i].ly,bottom);bottom=labels[i].ly-18;}
 for(const s of labels)svg+='<path d="M'+x(s.last.asOf)+','+s.target+' L'+(W-R+9)+','+s.ly+' H'+(W-R+14)+'" fill="none" stroke="'+s.color+'" stroke-width=".8" stroke-dasharray="2 2"/><text class="chart-end-label" x="'+(W-R+18)+'" y="'+(s.ly+4)+'" style="fill:'+s.color+';font-weight:600;font-size:'+(W<600?9:11)+'px">'+esc(s.name)+'</text>';
 svg+='<line id="all-crosshair" visibility="hidden" y1="'+T+'" y2="'+(H-B)+'" stroke="#737373" stroke-dasharray="3 3"/></svg>';$('#chart-svg').innerHTML=svg;
 const svgEl=frame.querySelector('svg'),cross=frame.querySelector('#all-crosshair');
 frame.onpointermove=e=>{const box=svgEl.getBoundingClientRect(),px=(e.clientX-box.left)/box.width*W;if(px<L||px>W-R){tip.classList.add('hidden');cross.setAttribute('visibility','hidden');return;}
  const date=dates.reduce((best,d)=>Math.abs(x(d)-px)<Math.abs(x(best)-px)?d:best,dates[0]);cross.setAttribute('x1',x(date));cross.setAttribute('x2',x(date));cross.setAttribute('visibility','visible');
  const actual=shown.flatMap(s=>s.rows.filter(r=>r.asOf===date).map(r=>({s,r})));
  tip.innerHTML='<strong>'+date+' · 当日实际观测</strong>'+actual.map(({s,r})=>'<div><span style="color:'+s.color+'">'+esc(s.name)+'</span><b>'+esc(quote(r))+' bp</b></div><small>'+type(s)+(r.tradeCount?' · '+r.tradeCount+'笔成交':'')+'</small>').join('')+'<p>未列出的公司当日无观测；不沿用旧值。</p>';
  tip.classList.remove('hidden');const rect=frame.getBoundingClientRect();tip.style.left=Math.max(8,Math.min(e.clientX-rect.left+14,rect.width-tip.offsetWidth-8))+'px';tip.style.top=Math.max(6,Math.min(e.clientY-rect.top+12,rect.height-tip.offsetHeight-8))+'px';
 };frame.onpointerleave=()=>{tip.classList.add('hidden');cross.setAttribute('visibility','hidden');};

}
