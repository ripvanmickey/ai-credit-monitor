function cdsTrend(series){
 if(!series)return {status:'missing',reason:'未取得合格连续序列'};
 if(series.measurement==='press_report')return {status:'reports',reason:'仅有独立报道，条款／时点可能不同，不拟合趋势'};
 const to=series.rows.at(-1).asOf,end=Date.parse(to);
 const rows=series.rows.filter(r=>end-Date.parse(r.asOf)<=29*86400000).slice(-20),n=rows.length;
 const from=rows[0].asOf,days=(end-Date.parse(from))/86400000;
 const base={measurement:series.measurement,from,to,n,days,latest:rows.at(-1).value};
 if(n<5||days<7)return {...base,status:'insufficient',reason:'需至少5个观测日且跨度不少于7天'};
 const xs=rows.map(r=>(Date.parse(r.asOf)-Date.parse(from))/86400000),ys=rows.map(r=>r.value),mx=xs.reduce((a,b)=>a+b,0)/n,my=ys.reduce((a,b)=>a+b,0)/n;
 const xx=xs.reduce((a,x)=>a+(x-mx)**2,0),xy=xs.reduce((a,x,i)=>a+(x-mx)*(ys[i]-my),0),yy=ys.reduce((a,v)=>a+(v-my)**2,0),slope=xy/xx;
 const fittedStart=my-slope*mx,fittedChange=slope*days,fittedPct=fittedStart>0?100*fittedChange/fittedStart:null;
 return {...base,status:'ok',direction:fittedPct==null?'无法判断':fittedPct>5?'走阔':fittedPct< -5?'收窄':'大致平稳',weeklyBp:slope*7,rSquared:yy?Math.max(0,Math.min(1,xy*xy/(xx*yy))):null,fittedPct,changeBp:ys.at(-1)-ys[0],changePct:ys[0]?100*(ys.at(-1)/ys[0]-1):null};
}
function summaryStats(rows,base){
 const last=rows.at(-1),n=rows.length,values=rows.map(o=>o.value);
 const change=q=>{if(n<=q)return null;const first=rows[n-1-q];if((Date.parse(last.asOf)-Date.parse(first.asOf))/86400000>q*2+4)return null;return {bp:last.value-first.value,pct:first.value?100*(last.value/first.value-1):null,from:first.asOf,to:last.asOf,quoteDays:q};};
 return {...base,rows,n,from:rows[0].asOf,to:last.asOf,latest:last.value,day:change(1),change5:change(5),change20:change(20),percentile:n>=20?100*(values.filter(v=>v<last.value).length+values.filter(v=>v===last.value).length/2)/n:null,min:Math.min(...values),max:Math.max(...values)};
}
function analyzeSnapshot(data){
 const groups=new Map();
 for(const o of data.observations||[]){
  if(o.quoteType!=='daily_close'||o.operator!=='='||o.tenor!=='5Y'||o.currency!=='USD'||!o.seriesKey||!Number.isFinite(o.value))continue;
  const key=[o.entityId,o.seriesKey,o.tenor,o.currency,o.seniority??'unknown',o.restructuring??'unknown'].join('|');
  if(!groups.has(key))groups.set(key,[]);groups.get(key).push(o);
 }
 const series=[...groups.entries()].map(([key,records])=>{
  const byDate=new Map();for(const o of records){const old=byDate.get(o.asOf);if(!old||(o.collectedAt||'')>(old.collectedAt||''))byDate.set(o.asOf,o);}
  const rows=[...byDate.values()].sort((a,b)=>a.asOf.localeCompare(b.asOf));const last=rows.at(-1),previous=rows.at(-2),n=rows.length;
  const change=q=>{if(n<=q)return null;const base=rows[n-1-q];if((Date.parse(last.asOf)-Date.parse(base.asOf))/86400000>q*2+4)return null;return {bp:last.value-base.value,pct:base.value?100*(last.value/base.value-1):null,from:base.asOf,to:last.asOf,quoteDays:q};};
  const values=rows.map(o=>o.value),less=values.filter(v=>v<last.value).length,equal=values.filter(v=>v===last.value).length;
  return {key,entityId:last.entityId,name:data.entities.find(e=>e.id===last.entityId)?.name||last.entityId,instrument:last.instrument,sourceName:'Investing.com',measurement:'daily_close',sourceUrl:last.sourceUrl,n,from:rows[0].asOf,to:last.asOf,latest:last.value,day:change(1),change5:change(5),change20:change(20),percentile:n>=20?100*(less+equal/2)/n:null,min:Math.min(...values),max:Math.max(...values),rows};
 }).sort((a,b)=>['ORCL','AMZN','MSFT','AMD','INTC','SPCX'].indexOf(a.entityId)-['ORCL','AMZN','MSFT','AMD','INTC','SPCX'].indexOf(b.entityId));
 let common=null;
 if(series.length>1){
  const dates=series[0].rows.map(o=>o.asOf).filter(date=>series.every(s=>s.rows.some(o=>o.asOf===date)));
  if(dates.length>=2){
   const from=dates[0],to=dates.at(-1);const pairs=series.map(s=>{const base=s.rows.find(o=>o.asOf===from).value,last=s.rows.find(o=>o.asOf===to).value;return {entityId:s.entityId,name:s.name,fromValue:base,toValue:last,bp:last-base,pct:base?100*(last/base-1):null,points:dates.map(date=>({date,value:s.rows.find(o=>o.asOf===date).value/base*100}))};});
   const changes=pairs.map(p=>p.pct).filter(Number.isFinite).sort((a,b)=>a-b);const mid=Math.floor(changes.length/2);common={from,to,n:dates.length,companies:pairs.length,widened:pairs.filter(p=>p.bp>0).length,medianPct:changes.length%2?changes[mid]:(changes[mid-1]+changes[mid])/2,pairs};
  }
 }
 const tradeSeries=(data.tradeStudy?.series||[]).filter(s=>s.rows.length).map(s=>summaryStats(s.rows.map(r=>({...r,operator:'=',entityId:s.entityId,tenor:'approx5Y',currency:'USD',seniority:'senior',restructuring:null,quoteType:'trade_median',sourceTitle:'DTCC · 已披露成交的日内中位数',sourceUrl:r.sourceUrls[0],publishedAt:r.lastDisclosureDate,note:'USD优先单名CDS，剩余期限4.4—5.6年；'+r.tradeCount+'笔符合条件的披露成交，未加权中位数，非收盘报价。源文件可能随后订正。'})),{key:s.seriesKey,entityId:s.entityId,name:data.entities.find(e=>e.id===s.entityId)?.name||s.entityId,instrument:'约5年期 USD 优先单名CDS',sourceName:'DTCC公开成交',measurement:'trade_median',sourceUrl:'https://pddata.dtcc.com/',checkedAt:data.tradeStudy.checkedAt}));
 const reportSeries=data.entities.map(e=>{
  const rows=(data.observations||[]).filter(o=>o.entityId===e.id&&o.quoteType!=='daily_close').sort((a,b)=>a.asOf.localeCompare(b.asOf)||Number(b.isIntradayExtreme)-Number(a.isIntradayExtreme)||(a.observedAt||'').localeCompare(b.observedAt||'')||a.publishedAt.localeCompare(b.publishedAt));
  return rows.length?{entityId:e.id,name:e.name,measurement:'press_report',sourceName:'独立报道点位',instrument:'按各记录的期限与来源',rows,n:rows.length,from:rows[0].asOf,to:rows.at(-1).asOf,latest:rows.at(-1).value,day:null,change5:null,change20:null,percentile:null}:null;
 }).filter(Boolean);
 const trends=data.entities.map(e=>{const s=series.find(s=>s.entityId===e.id)||tradeSeries.find(s=>s.entityId===e.id)||reportSeries.find(s=>s.entityId===e.id);return {entityId:e.id,name:e.name,sourceName:s?.sourceName||null,...cdsTrend(s)};});
 return {revision:data.revision,series,tradeSeries,reportSeries,trends,common,coverage:data.tradeStudy?.summary||{},tradeStudyPeriod:data.tradeStudy?{from:data.tradeStudy.from,to:data.tradeStudy.to,checkedAt:data.tradeStudy.checkedAt,files:data.tradeStudy.availableFiles}:null,method:{percentile:'同源同口径区间内中位秩：(小于当前值的样本数 + 同值样本数/2) / 样本数 × 100；至少20个观测日。',change:'日线按报价日，DTCC按有合格成交的观测日计算；不是同一种日频数据。报道点位不计算。',comparison:'共同日期对比仅使用Investing日线交集，不混入DTCC成交中位数或报道点位。'}};
}

function allCompanySeries(snapshot,analysis){
 return snapshot.entities.map(e=>{
  const source=analysis.series.find(s=>s.entityId===e.id)||analysis.tradeSeries.find(s=>s.entityId===e.id)||analysis.reportSeries.find(s=>s.entityId===e.id);
  if(!source)return null;
  let rows=source.rows;
  if(source.measurement==='press_report'){
   const byDate=new Map();for(const r of rows)if(r.tenor==='5Y'&&!r.isIntradayExtreme)byDate.set(r.asOf,r);
   rows=[...byDate.values()].sort((a,b)=>a.asOf.localeCompare(b.asOf));
  }
  rows=rows.filter(r=>Number.isFinite(r.value)&&r.value>0);
  return rows.length?{...source,rows,entityId:e.id,name:e.name}:null;
 }).filter(Boolean);
}
