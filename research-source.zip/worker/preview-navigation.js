// srcdoc inherits its parent's base URL. Handle fragments without navigating
// the child frame back to the outer preview document.
document.addEventListener('click',event=>{
 const link=event.target.closest?.('a[href]');if(!link||link.hasAttribute('download'))return;
 const href=link.getAttribute('href');if(!/^(?:\.\/)?(?:index\.html)?#/.test(href))return;
 event.preventDefault();
 let id;try{id=decodeURIComponent(href.slice(href.indexOf('#')+1));}catch{return;}
 const target=id?document.getElementById(id):document.documentElement;
 target?.scrollIntoView({behavior:'smooth',block:'start'});
});
