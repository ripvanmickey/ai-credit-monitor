function mergeMarketHistory(base,extra){const m=new Map();for(const o of [...(base||[]),...(extra||[])])m.set(o.id,o);return [...m.values()];}
function marketMonthChange(rows,valueKey='value'){
 if(rows.length<2)return null;const end=rows.at(-1),target=Date.parse(end.asOf)-30*86400000;
 const candidates=rows.slice(0,-1).filter(r=>Number.isFinite(r[valueKey])&&Math.abs(Date.parse(r.asOf)-target)<=3*86400000).sort((a,b)=>Math.abs(Date.parse(a.asOf)-target)-Math.abs(Date.parse(b.asOf)-target)||a.asOf.localeCompare(b.asOf));
 const base=candidates[0];if(!base||!Number.isFinite(end[valueKey]))return null;
 const delta=end[valueKey]-base[valueKey],pct=base[valueKey]!==0?100*delta/Math.abs(base[valueKey]):null;
 return {from:base.asOf,to:end.asOf,days:(Date.parse(end.asOf)-Date.parse(base.asOf))/86400000,delta,pct,n:rows.filter(r=>r.asOf>=base.asOf&&r.asOf<=end.asOf).length};
}
