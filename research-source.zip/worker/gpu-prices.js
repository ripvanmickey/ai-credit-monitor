const GPU_SOURCES=[
 {id:'aws',name:'AWS',url:'https://b0.p.awsstatic.com/pricing/2.0/meteredUnitMaps/ec2/USD/current/ec2-ondemand-without-sec-sel/US%20East%20(N.%20Virginia)/Linux/index.json',page:'https://aws.amazon.com/ec2/pricing/on-demand/'},
 {id:'azure',name:'Azure',url:"https://prices.azure.com/api/retail/prices?"+new URLSearchParams({'$filter':"serviceName eq 'Virtual Machines' and armRegionName eq 'eastus' and armSkuName eq 'Standard_ND96isr_H100_v5' and priceType eq 'Consumption'"}),page:'https://learn.microsoft.com/en-us/rest/api/cost-management/retail-prices/azure-retail-prices'},
 {id:'gcp',name:'Google Cloud',url:'https://cloud.google.com/products/compute/pricing/accelerator-optimized',page:'https://cloud.google.com/products/compute/pricing/accelerator-optimized'},
 {id:'runpod',name:'Runpod',url:'https://www.runpod.io/pricing',page:'https://www.runpod.io/pricing'},
 {id:'lambda',name:'Lambda',url:'https://lambda.com/pricing',page:'https://lambda.com/pricing'}
];
const gpuPlain=s=>s.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi,' ').replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi,' ').replace(/<[^>]+>/g,' ').replace(/&nbsp;|&#160;/g,' ').replace(/&amp;/g,'&').replace(/\s+/g,' ').trim();
function parseGPUPrices(source,text,at){
 const day=at.slice(0,10),out=[],plain=gpuPlain(text);
 const add=(model,sku,price,gpus,region,billing,qualified,note,extra={})=>{
  if(!Number.isFinite(price)||price<=0||price>200||!Number.isInteger(gpus)||gpus<=0)throw Error('Invalid GPU price or count');
  const key=[source.id,sku,region,billing].join(':');
  out.push({id:'gpu:'+key+':'+day+':'+price,metric:'gpu_price',entityId:source.id.toUpperCase(),seriesKey:key,method:'matched_quote',specification:model+'; '+sku+'; '+gpus+' GPU instance',model,sku,gpus,region,billing,priceType:billing,trendEligible:qualified,value:price,unit:'USD/GPU-hour',asOf:day,publishedAt:at,observedAt:at,sourceUrl:source.url,sourceTitle:source.name+' official public pricing',note,currency:'USD',...extra});
 };
 if(source.id==='aws'){
  const d=JSON.parse(text),rows=Object.values(d.regions?.['US East (N. Virginia)']||{}),r=rows.find(r=>r['Instance Type']==='p5.48xlarge'&&r['Operating System']==='Linux'&&r['Pre Installed S/W']==='NA'&&r['License Model']==='No License required');
  if(!r)throw Error('AWS target SKU/region/Linux not found');
  add('NVIDIA H100 80GB','p5.48xlarge',Number(r.price)/8,8,'us-east-1','on_demand',true,'Linux按需整机价÷8，含CPU／内存等整机资源；非GPU裸卡成交价。',{instanceHourly:Number(r.price),providerUpdatedAt:d.manifest?.hawkFilePublicationDate});
 }else if(source.id==='azure'){
  const d=JSON.parse(text);if(d.NextPageLink)throw Error('Azure truncated result');
  const rows=(d.Items||[]).filter(r=>r.currencyCode==='USD'&&r.armRegionName==='eastus'&&r.armSkuName==='Standard_ND96isr_H100_v5'&&r.type==='Consumption'&&r.unitOfMeasure==='1 Hour'&&r.productName==='Virtual Machines NDsr H100 v5 Series');
  const regular=rows.filter(r=>r.skuName==='ND96isrH100v5'&&r.meterName==='ND96isrH100v5');
  if(regular.length!==1)throw Error('Azure regular meter ambiguous');
  for(const r of [regular[0],...rows.filter(r=>r.skuName==='ND96isrH100v5 Spot'&&r.meterName==='ND96isrH100v5 Spot')]){
   const spot=r.skuName.endsWith(' Spot');add('NVIDIA H100 80GB','Standard_ND96isr_H100_v5',r.retailPrice/8,8,'eastus',spot?'spot':'on_demand',!spot,'Azure官方零售整机价÷8，Linux，未计税费；Spot可被回收，只作旁证。',{instanceHourly:r.retailPrice,meterId:r.meterId,effectiveAt:r.effectiveStartDate});
  }
 }else if(source.id==='gcp'){
  if(!plain.includes('Iowa (us-central1)'))throw Error('GCP default region changed');
  for(const [sku,model] of [['a3-highgpu-8g','NVIDIA H100 80GB'],['a3-ultragpu-8g','NVIDIA H200 141GB']]){
   const rows=[...text.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)].map(m=>m[1]).filter(s=>gpuPlain(s).startsWith(sku+' '));if(rows.length!==1)throw Error('GCP SKU row ambiguous: '+sku);
   const cells=[...rows[0].matchAll(/<td\b[^>]*>([\s\S]*?)<\/td>/gi)].map(m=>gpuPlain(m[1]));const m=cells[3]?.match(/^\$([\d,.]+)\s*\/\s*1 hour$/);if(!m||!cells[2].includes('GPUs: 8')||!cells[1].includes(model.includes('H200')?'H200':'H100'))throw Error('GCP on-demand column changed');
   const rate=Number(m[1].replaceAll(',',''));add(model,sku,rate/8,8,'us-central1','on_demand',true,'Iowa默认区域；读取Price列，非DWS／Spot／承诺折扣。整机价÷8，含CPU／内存及页面注明的捆绑资源。',{instanceHourly:rate});
  }
 }else if(source.id==='runpod'){
  for(const model of ['H100 SXM','H100 PCIe']){
   const segment=plain.match(new RegExp('Runpod rents the '+model+' at \\$([\\d.]+)/hr on Secure Cloud, or from \\$([\\d.]+)/hr on Community Cloud'));
   if(!segment)throw Error('Runpod explicit cloud-type FAQ missing');
   add('NVIDIA '+model+' 80GB',model,Number(segment[1]),1,'global_unspecified','secure_on_demand',false,'Secure Cloud官方参考价，页面未固定地区；仅作挂牌价参考，不进入固定地区的周期评分。');
   add('NVIDIA '+model+' 80GB',model,Number(segment[2]),1,'global_unspecified','community_from',false,'Community Cloud起步价，供应商与地区会变化；不进入趋势评分，不能与Secure Cloud拼接。');
  }
 }else if(source.id==='lambda'){
  const future=plain.match(/These prices take effect ([A-Za-z]+ \d{1,2}, \d{4}), at (\d\d:\d\d) UTC/);if(!future)throw Error('Lambda effective-date notice changed; manual review required');
  const effectiveAt=new Date(future[1]+' '+future[2]+' UTC').toISOString();
  const pattern=/NVIDIA HGX H100\s*<\/td>/; // Parse table rows only, never cluster commitment prices.
  const rows=[...text.matchAll(/<tr\b[^>]*>([\s\S]*?)<\/tr>/gi)].map(m=>gpuPlain(m[1]));
  const row=rows.find(r=>r.startsWith('NVIDIA HGX H100 '));const price=row?.match(/\$([\d.]+)/);if(!price)throw Error('Lambda GPU table requires manual review');
  add('NVIDIA H100 SXM 80GB','8x-HGX-H100',Number(price[1]),8,'global_unspecified','announced_on_demand',false,'官方公告价，地区未固定；生效前不视为当前可租价格。',{effectiveAt,announced:true});
 }
 if(!out.length)throw Error('No verified GPU rows');return out;
}
async function readGPUPrices(env){
 const o=env.BUCKET?await env.BUCKET.get('gpu-prices.json'):null,p=o?JSON.parse(await o.text()):{...GPU_PRICE_SEED,persistence:env.BUCKET?'seed':'unavailable'};
 return {...p,observations:mergeMarketHistory(MARKET_HISTORY_SEED.gpu,p.observations),historyAttribution:MARKET_HISTORY_SEED.attribution};
}
async function refreshGPUPrices(env,at=new Date().toISOString()){
 const previous=await readGPUPrices(env),observations=[...(previous.observations||[])],checks=[];const results=await Promise.allSettled(GPU_SOURCES.map(async s=>{
  const r=await fetch(s.url,{signal:AbortSignal.timeout(25000),headers:{'Accept':'application/json,text/html'}});if(!r.ok)throw Error('HTTP '+r.status);
  let bytes=new Uint8Array(await r.arrayBuffer());if(bytes.length>10000000)throw Error('Source too large');if(bytes[0]===31&&bytes[1]===139)bytes=new Uint8Array(await new Response(new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'))).arrayBuffer());
  return parseGPUPrices(s,new TextDecoder().decode(bytes),at);
 }));
 results.forEach((r,i)=>{const source=GPU_SOURCES[i];if(r.status==='fulfilled'){for(const o of r.value){const last=observations.filter(p=>p.seriesKey===o.seriesKey).sort((a,b)=>a.publishedAt.localeCompare(b.publishedAt)).at(-1);if(last&&last.asOf===o.asOf&&last.value===o.value&&last.effectiveAt===o.effectiveAt)continue;if(observations.some(p=>p.id===o.id))o.id+=':'+at;observations.push(o);}checks.push({sourceId:source.id,status:'ok',rows:r.value.length,at});}else checks.push({sourceId:source.id,status:'failed',at,note:String(r.reason?.message||r.reason).slice(0,180)});});
 const value={schemaVersion:1,checkedAt:at,status:checks.every(c=>c.status==='ok')?'ok':checks.some(c=>c.status==='ok')?'partial':'failed',observations,checks,sources:GPU_SOURCES};
 if(env.BUCKET)await env.BUCKET.put('gpu-prices.json',JSON.stringify(value),{httpMetadata:{contentType:'application/json'}});return value;
}
function gpuPriceSummary(raw,now=new Date().toISOString()){
 const groups=new Map();for(const o of raw.observations||[]){const a=groups.get(o.seriesKey)||[];a.push(o);groups.set(o.seriesKey,a);}
 return {checkedAt:raw.checkedAt,status:raw.status,checks:raw.checks,sources:GPU_SOURCES,historyAttribution:MARKET_HISTORY_SEED.attribution,series:[...groups].map(([key,all])=>{
  const daily=all.sort((a,b)=>a.asOf.localeCompare(b.asOf)||a.publishedAt.localeCompare(b.publishedAt)).filter((o,i,a)=>i===a.length-1||o.asOf!==a[i+1].asOf),last=daily.at(-1),pending=last.effectiveAt&&Date.parse(last.effectiveAt)>Date.parse(now);
  return {key,latest:last,rows:daily,n:daily.length,pending:!!pending,stale:Date.parse(now)-Date.parse(last.asOf)>14*86400000,trendEligible:!pending&&last.trendEligible===true,monthChange:pending?null:marketMonthChange(daily),historySource:daily.find(o=>o.archiveUrl)?.archivePublisher||null};
 })};
}
