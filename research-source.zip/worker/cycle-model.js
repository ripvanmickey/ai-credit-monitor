// Research rules v2. Thresholds are transparent heuristics, not fitted probabilities.
const CYCLE_CLOUDS=['MSFT','AMZN','GOOGL','ORCL'];
function analyzeCycle(snapshot,inputs,now=new Date().toISOString(),bondReport=null){
 const today=Date.parse(now),day=86400000,age=d=>(today-Date.parse(d))/day;
 const obs=[...(inputs.observations||[]),...(snapshot.cycleObservations||[])].filter(o=>Date.parse(o.publishedAt)<=today&&Date.parse(o.asOf)<=today);
 const groups=metric=>{const m=new Map();for(const o of obs.filter(o=>o.metric===metric&&(metric!=='gpu_price'||(o.trendEligible!==false&&(!o.effectiveAt||Date.parse(o.effectiveAt)<=today))))){const a=m.get(o.seriesKey)||[];a.push(o);m.set(o.seriesKey,a);}return [...m.values()].map(a=>a.sort((a,b)=>a.asOf.localeCompare(b.asOf)||a.publishedAt.localeCompare(b.publishedAt)).filter((o,i,a)=>i===a.length-1||o.asOf!==a[i+1].asOf));};
 const fundamentals=metric=>{
  const candidates=groups(metric).map(rows=>{const last=rows.at(-1);return {rows,last,stale:age(last.publishedAt)>120||age(last.asOf)>150};}).sort((a,b)=>b.last.asOf.localeCompare(a.last.asOf)||b.last.publishedAt.localeCompare(a.last.publishedAt));
  return candidates.filter((s,i)=>candidates.findIndex(c=>c.last.entityId===s.last.entityId)===i);
 };
 const unknown=(id,title,reason,details=[])=>({id,title,level:null,label:'证据不足',reason,details});
 const make=(id,title,level,reason,details)=>({id,title,level,label:['未达阈值','预警','压力'][level],reason,details});
 const pct=(a,b)=>100*(a/b-1);
 const prices=groups('gpu_price').map(rows=>{
  const end=rows.at(-1),base=rows.filter(r=>Date.parse(end.asOf)-Date.parse(r.asOf)>=28*day&&Date.parse(end.asOf)-Date.parse(r.asOf)<=42*day).at(-1);
  const tail=rows.slice(-3),persistent=tail.length===3&&tail[0].value>tail[1].value&&tail[1].value>tail[2].value&&Date.parse(tail[2].asOf)-Date.parse(tail[0].asOf)>=14*day;
  const change=base?pct(end.value,base.value):null,valid=age(end.asOf)<=14&&base&&rows.length>=3;
  return {entityId:end.entityId,seriesKey:end.seriesKey,from:base?.asOf,to:end.asOf,value:end.value,change,valid:!!valid,level:valid?(change<=-20&&persistent?2:change<=-10?1:0):null,sourceUrl:end.sourceUrl,note:end.note};
 });
 const priceValid=prices.filter(p=>p.valid),providers=new Set(priceValid.map(p=>p.entityId)),priceBad=priceValid.filter(p=>p.level>=1),priceRed=priceValid.filter(p=>p.level===2);
 const pricing=providers.size<2?unknown('pricing','算力租价','至少需要两家供应商的同规格、同地区、同计费条款历史序列；静态挂牌价不能推断价格趋势。',prices):make('pricing','算力租价',new Set(priceRed.map(p=>p.entityId)).size>=2?2:new Set(priceBad.map(p=>p.entityId)).size>=2?1:0,'每条序列各自比较约30日前；至少两家供应商同向下跌才计入行业信号。',prices);
 const analysis=analyzeSnapshot(snapshot);
 const creditDetails=CYCLE_CLOUDS.map(id=>{
  const s=analysis.series.find(s=>s.entityId===id)||analysis.tradeSeries.find(s=>s.entityId===id),rows=s?.rows||[],last=rows.at(-1),base=rows.length>=21?rows.at(-21):null;
  const span=base?(Date.parse(last.asOf)-Date.parse(base.asOf))/day:null;
  const valid=!!(base&&last&&age(last.asOf)<=7&&span>=15&&span<=60),changeBp=base?last.value-base.value:null,changePct=base?pct(last.value,base.value):null;
  return {entityId:id,name:s?.name||id,measurement:s?.measurement,from:base?.asOf,to:last?.asOf,value:last?.value,changeBp,changePct,valid,level:valid?(changePct>=40&&changeBp>=20?2:changePct>=20&&changeBp>=10?1:0):null,sourceUrl:last?.sourceUrl||s?.sourceUrl,note:!valid?'需21个同源观测日、跨度15—60天，最新报价不超过7天。':'同源前后比较，不把不同公司的绝对利差混合。'};
 });
 const eligible=creditDetails.filter(c=>c.valid),warn=eligible.filter(c=>c.level>=1),red=eligible.filter(c=>c.level===2);
 let credit=eligible.length<3?unknown('credit','云厂商信用','四家核心云厂商至少三家具有合格序列，才判断信用压力是否扩散。Neocloud报道点位仅作旁证。',creditDetails):make('credit','云厂商信用',red.length>=3?2:warn.length>=2?1:0,'观察MSFT、AMZN、GOOGL、ORCL。预警需至少两家走阔≥20%且≥10bp；压力需至少三家≥40%且≥20bp。',creditDetails);
 const cdsLevel=credit.level;
 const cashDetails=CYCLE_CLOUDS.map(id=>{const b=bondReport?.bonds?.find(b=>b.entityId===id),m=b?.monthChange,valid=!!(m&&m.n>=10&&m.days>=27&&m.days<=33&&!b.stale&&age(m.to)>=0&&age(m.to)<=7),level=valid?(m.pct>=40&&m.delta>=20?2:m.pct>=20&&m.delta>=10?1:0):null;return {entityId:id,valid,level,from:m?.from,to:m?.to,changeBp:m?.delta,changePct:m?.pct};});
 const cashValid=cashDetails.filter(d=>d.valid),cashWarn=cashValid.filter(d=>d.level>=1),cashRed=cashValid.filter(d=>d.level===2),cashLevel=cashValid.length<3?null:cashRed.length>=3?2:cashWarn.length>=2?1:0;
 const levels=[cdsLevel,cashLevel].filter(l=>l!==null),jointLevel=levels.length?Math.max(...levels):null;
 if(bondReport){credit={...credit,level:jointLevel,label:jointLevel===null?'证据不足':['未达阈值','预警','压力'][jointLevel],reason:'CDS与公司债各自观察核心四家公司；各市场至少三家合格才评分。取两市场较高压力等级，同一信用维度只计一次；信号分化另行标注。'};}
 credit.marketSignals={cds:{level:cdsLevel,eligible:eligible.length,details:creditDetails},bonds:{level:cashLevel,eligible:cashValid.length,details:cashDetails},rule:'各市场至少三家合格。两家走阔≥20%且≥10bp为预警，三家≥40%且≥20bp为压力；同信用维度取较高等级，不相加。'};
 const orderDetails=fundamentals('rpo').filter(s=>CYCLE_CLOUDS.includes(s.last.entityId)).map(s=>{
  const r=s.rows,l=s.last,p=r.at(-2),q=r.at(-3),quarter=p?(Date.parse(l.asOf)-Date.parse(p.asOf))/day:0,priorQuarter=q?(Date.parse(p.asOf)-Date.parse(q.asOf))/day:0;
  const valid=!s.stale&&quarter>=60&&quarter<=120,change=p?pct(l.value,p.value):null,priorChange=q?pct(p.value,q.value):null;
  return {entityId:l.entityId,from:p?.asOf,to:l.asOf,value:l.value,unit:l.unit,change,priorChange,valid,level:valid?(change<=-5&&priorQuarter>=60&&priorQuarter<=120&&priorChange<=-5?2:change<=-5?1:0):null,sourceUrl:l.sourceUrl,note:l.note};
 });
 const orderValid=orderDetails.filter(o=>o.valid),orderBad=orderValid.filter(o=>o.level>=1),orderRed=orderValid.filter(o=>o.level===2);
 const orders=orderValid.length<2?unknown('orders','订单兑现','至少两家云厂商具有同口径连续季度RPO。单家公司、单季小幅下降不足以判定砍单。',orderDetails):make('orders','订单兑现',orderRed.length>=2?2:orderBad.length>=2?1:0,'至少两家RPO环比下降≥5%为预警；两家连续两季各下降≥5%为压力。RPO不是纯AI订单，需人工核对季节性、汇率与重大合同。',orderDetails);
 const dsoDetails=fundamentals('dso').filter(s=>s.last.entityId==='NVDA'&&s.last.method==='issuer_reported').map(s=>{
  const r=s.rows,l=s.last,p=r.at(-2),q=r.at(-3),gap=p?(Date.parse(l.asOf)-Date.parse(p.asOf))/day:0,priorGap=q?(Date.parse(p.asOf)-Date.parse(q.asOf))/day:0;
  const change=p?l.value-p.value:null,valid=!s.stale&&gap>=60&&gap<=120;
  const cash=fundamentals('ocf_net_income').find(c=>c.last.entityId===l.entityId&&c.last.asOf===l.asOf&&!c.stale)?.last;
  return {entityId:l.entityId,from:p?.asOf,to:l.asOf,value:l.value,change,valid,level:valid?(q&&priorGap>=60&&priorGap<=120&&change>=10&&p.value-q.value>=10&&cash&&cash.value<.8?2:change>=10||pct(l.value,p.value)>=20?1:0):null,sourceUrl:l.sourceUrl,note:l.note};
 });
 const dsoValid=dsoDetails.filter(d=>d.valid);
 const collections=!dsoValid.length?unknown('collections','回款质量','NVDA公司披露DSO需至少两个连续季度；不把期末应收÷收入代理值与公司DSO混算。',dsoDetails):make('collections','回款质量',Math.max(...dsoValid.map(d=>d.level)),'NVDA单家公司代理指标：DSO环比增加≥10天或≥20%为预警；连续两季各增加≥10天且同季经营现金流／净利润<0.8，才记为压力。不是坏账认定。',dsoDetails);
 const dimensions=[pricing,credit,orders,collections],known=dimensions.filter(d=>d.level!==null),triggered=known.filter(d=>d.level>=1),points=known.reduce((n,d)=>n+d.level,0),missing=4-known.length;
 let stage=missing?'证据不完整，暂不能确认反转':triggered.length===0?'当前未达共振阈值':'出现局部压力';
 if(triggered.length>=2)stage=missing?'多项预警，仍有证据缺口':'多项预警，等待交叉验证';
 if(triggered.length>=3&&credit.level>=1&&(pricing.level>=1||orders.level>=1))stage='出现跨维度风险共振';
 if(triggered.length===4)stage='四项风险共振';
 return {schemaVersion:1,ruleVersion:'capital-cycle-v2',computedAt:now,creditCheckedAt:snapshot.checkedAt,fundamentalsCheckedAt:inputs.checkedAt,stage,coverage:known.length,total:4,triggered:triggered.length,points:{lower:points,upper:points+2*missing,max:8},dimensions,leading:(inputs.leading||[]),context:inputs.context||[],observations:obs,method:'研究性监测规则，未经历史回测校准；分值区间是缺失维度取0—2分的可能范围，不是概率。季度与市场数据不合并成伪日频历史。'};
}
