const companyLogoFiles = Object.freeze({
  AMD: 'amd', AMZN: 'aws', AWS: 'aws', AZURE: 'microsoft',
  AVGO: 'broadcom', CRWV: 'coreweave', DLR: 'digitalrealty', EQIX: 'equinix',
  GCP: 'google-cloud', GOOGL: 'google', INTC: 'intel', IREN: 'iren',
  LAMBDA: 'lambda', META: 'meta', MRVL: 'marvell', MSFT: 'microsoft', NBIS: 'nebius', NVDA: 'nvidia',
  ORCL: 'oracle', RUNPOD: 'runpod', SFTBY: 'softbank', SPCX: 'spacex',
});
function companyLogo(id) {
  if (!Object.hasOwn(companyLogoFiles, id)) return '';
  const file = companyLogoFiles[id];
  const src = typeof embeddedCompanyLogos === 'undefined'
    ? '/cycle/logo-' + file + '.png'
    : embeddedCompanyLogos[file];
  if (!src) return '';
  return '<img class="order-company-logo" src="' + src + '" alt="" width="28" height="28" loading="lazy">';
}
