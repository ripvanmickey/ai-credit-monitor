// Keep each company's color consistent across chart modes and filters.
const companyChartColors = {
  ORCL: '#dc2626',
  CRWV: '#0891b2',
  MSFT: '#7c3aed',
  AMZN: '#2563eb',
  GOOGL: '#be185d',
  META: '#475569',
  IREN: '#4338ca',
  NBIS: '#4d7c0f',
  EQIX: '#713f12',
  DLR: '#3f6212',
  NVDA: '#15803d',
  SFTBY: '#1e3a8a',
  AMD: '#c2410c',
  INTC: '#115e59',
  SPCX: '#a16207',
  AVGO: '#a21caf',
  MRVL: '#1d4ed8',
};

function companyChartColor(companyId) {
  return companyChartColors[companyId] ?? '#475569';
}
