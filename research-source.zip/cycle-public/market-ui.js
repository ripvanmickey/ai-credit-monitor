let gpuData=null,bondData=null;
const money=v=>Number.isFinite(v)?v.toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2}):'—';
function changeBadge(change,unit='%',stale=false){
 if(!change)return '<small class="move muted">近1月：样本不足</small>';
 const raw=unit==='%'?change.pct:change.delta;if(!Number.isFinite(raw))return '<small>基准为零，无法计算</small>';
 const v=Math.abs(raw)<1e-8?0:raw,cls=v>0?'rise':v<0?'fall':'flat',arrow=v>0?'↑':v<0?'↓':'→';
 return '<span class="move '+cls+'">'+arrow+' '+(v>0?'+':'')+money(v)+esc(unit)+(stale?' · 旧窗口':'')+'</span><small>'+esc(change.from)+' → '+esc(change.to)+'</small>';
}
function monthPoints(rows,dateKey='asOf'){if(!rows.length)return rows;const cutoff=Date.parse(rows.at(-1)[dateKey])-31*86400000;return rows.filter(r=>Date.parse(r[dateKey])>=cutoff);}

const providerNames={AWS:'AWS',AZURE:'Azure',GCP:'Google Cloud',RUNPOD:'Runpod',LAMBDA:'Lambda'};
const priceLabels={on_demand:'固定地区按需价',spot:'Spot参考价',secure_on_demand:'Secure Cloud地区未固定',community_from:'Community起步价',announced_on_demand:'公告按需价'};
function renderGpu(g){
 gpuData=g;$('#gpu-attribution').innerHTML='历史归档：'+link('https://gpurentalprices.com/data','GPU Rental Prices')+' · CC BY 4.0；按原采集日期读取，已检查更正清单。Google固定规格按需价尚无合格历史，未用其Spot记录替代。';$('#gpu-checked').textContent='最近检查：'+(g.checkedAt||'—').replace('T',' ').slice(0,19)+' UTC · '+({ok:'来源可读',partial:'部分来源失败',failed:'检查失败，保留旧值'})[g.status];
 const filter=$('#gpu-filter').value,list=g.series.filter(s=>filter==='all'||(filter==='on_demand'?s.trendEligible:!s.trendEligible));
 $('#gpu-rows').innerHTML=list.map(s=>{const o=s.latest;return '<tr><td><b>'+esc(providerNames[o.entityId]||o.entityId)+'</b><small>'+esc(o.model)+'</small></td><td>'+esc(o.sku)+'<small>'+esc(o.region)+' · '+o.gpus+'卡实例</small></td><td class="number"><b>$'+money(o.value)+'</b>'+changeBadge(s.monthChange,'%',s.stale)+(o.instanceHourly?'<small>整机 $'+money(o.instanceHourly)+'/小时 ÷ '+o.gpus+'</small>':'')+'</td><td><span class="pill">'+esc(s.pending?'尚未生效':priceLabels[o.billing]||o.billing)+'</span><small>'+esc(o.note)+'</small>'+(o.effectiveAt?'<small>生效日 '+esc(o.effectiveAt.slice(0,10))+'</small>':'')+'</td><td class="number">'+esc(o.asOf)+(s.stale?'<small>旧观测</small>':'')+'</td><td>'+s.n+'个观测日<small>'+link(o.sourceUrl,'官方来源')+(o.archiveUrl?' / '+link(o.archiveUrl,'历史归档'):'')+'</small></td></tr>';}).join('');
 const selected=$('#gpu-series').value;$('#gpu-series').innerHTML=g.series.map(s=>'<option value="'+esc(s.key)+'">'+esc(providerNames[s.latest.entityId]+' · '+s.latest.sku+' · '+s.latest.region+' · '+(priceLabels[s.latest.billing]||s.latest.billing))+'</option>').join('');if(g.series.some(s=>s.key===selected))$('#gpu-series').value=selected;else if(g.series.some(s=>s.trendEligible))$('#gpu-series').value=g.series.find(s=>s.trendEligible).key;renderGpuHistory();
}
function tinyHistory(target,points,unit){
 const format=v=>unit.includes('美元')?money(v):num(v,2);
 if(!points.length){$(target).innerHTML='<p class="blank">尚无同日可比数据。</p>';return;}
 if(points.length===1){$(target).innerHTML='<p class="blank"><b>'+esc(points[0].date)+'　'+format(points[0].value)+' '+esc(unit)+'</b><br>目前只有1个观测日，已建立基准；暂不判断涨跌方向。</p>';return;}
 const W=900,H=230,L=65,R=25,T=20,B=40,minDate=Date.parse(points[0].date),maxDate=Date.parse(points.at(-1).date),vs=points.map(p=>p.value);let low=Math.min(...vs),high=Math.max(...vs),pad=(high-low||Math.abs(high)*.05||1)*.2;low-=pad;high+=pad;
 const x=d=>L+(Date.parse(d)-minDate)/(maxDate-minDate||1)*(W-L-R),y=v=>T+(high-v)/(high-low)*(H-T-B);let path='',prev=null;
 for(const p of points){path+=(!prev||Date.parse(p.date)-Date.parse(prev)>7*86400000?'M':'L')+x(p.date)+','+y(p.value)+' ';prev=p.date;}
 $(target).innerHTML='<svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="'+esc(unit)+'历史走势" style="width:100%;display:block;margin-top:15px"><line x1="'+L+'" x2="'+(W-R)+'" y1="'+(H-B)+'" y2="'+(H-B)+'" stroke="#d5d5d5"/><path d="'+path+'" fill="none" stroke="#dc2626" stroke-width="2.5"/>'+points.map(p=>'<circle cx="'+x(p.date)+'" cy="'+y(p.value)+'" r="3" fill="#dc2626"><title>'+esc(p.date)+' '+format(p.value)+' '+esc(unit)+'</title></circle>').join('')+'<text x="'+L+'" y="'+(H-12)+'" fill="#787878" font-size="12">'+esc(points[0].date)+'</text><text x="'+(W-R)+'" y="'+(H-12)+'" text-anchor="end" fill="#787878" font-size="12">'+esc(points.at(-1).date)+'</text><text x="8" y="28" fill="#787878" font-size="12">'+num(high,2)+'</text><text x="8" y="'+(H-B)+'" fill="#787878" font-size="12">'+num(low,2)+'</text></svg>';
}
function renderGpuHistory(){const s=gpuData?.series.find(s=>s.key===$('#gpu-series').value);tinyHistory('#gpu-history',monthPoints(s?.rows||[]).map(r=>({date:r.asOf,value:r.value})),'美元／GPU小时');const m=s?.monthChange;$('#gpu-series-reading').textContent=!s?'':s.pending?'公告价尚未生效，不能用于判断当前供需。':!m?'该规格近月可比历史不足，暂不判断供需变化。':s.stale?'该规格属于旧窗口，不能推断当前供需。':Math.abs(m.pct)<1?'近月租价大致持平；没有涨价证据确认算力趋紧，仍需用量、利用率与可租容量交叉验证。':m.pct>0?'近月同规格租价上涨，支持供需趋紧的线索；尚不能区分需求增长与供给受限。':'近月同规格租价下跌，紧缺程度可能缓解；也需排除促销、代际替换与竞争影响。';}
function renderBonds(b){
 bondData=b;$('#bond-checked').textContent='最近资料检查：'+b.checkedAt.slice(0,10)+' · 不代表所有债券均为当日报价';
 $('#bond-rows').innerHTML=b.bonds.map(s=>{const o=s.latest;return '<tr><td><b>'+esc(s.name)+'</b><small>'+esc(s.isin)+'</small></td><td>'+num(s.coupon,3)+'%<small>'+esc(s.maturity)+(s.callable?' · 可赎回':' · 赎回条款见来源')+'</small></td><td class="number">'+(o?num(o.value,3)+'%':'—')+'<small>提供方计算YTM</small></td><td class="number">'+(o?.treasury5Y!=null?num(o.treasury5Y,2)+'%':'—')+'<small>'+link('https://www.federalreserve.gov/releases/h15/','H15名义5年')+'</small></td><td class="number">'+(o?.spreadBp!=null?num(o.spreadBp,1):'—')+changeBadge(s.monthChange,'bp',s.stale)+'<small>'+(o?.treasury5Y==null?'缺同日基准，不跨日填补':'与5年美债相减')+'</small></td><td>'+esc(s.direction)+(s.monthChange?'':'<small>不足一个月，以下为短区间变化</small>')+'<small>5日 '+signed(s.change5?.bp,'bp')+' / 20日 '+signed(s.change20?.bp,'bp')+'</small>'+(s.directionWindow?'<small>'+esc(s.directionWindow.from)+' → '+esc(s.directionWindow.to)+'</small>':'<small>配对样本 '+s.matched+'日</small>')+'</td><td>'+esc(o?.asOf||'—')+(s.stale?'<small>旧样本</small>':'')+(s.latestQuote&&s.latestQuote.asOf!==o?.asOf?'<small>较新YTM '+esc(s.latestQuote.asOf)+'未配对国债</small>':'')+(s.alternative&&s.alternative.asOf>o?.asOf?'<small>另源 '+esc(s.alternative.asOf)+' '+num(s.alternative.value,2)+'%（未拼接）</small>':'')+'<small>'+link(s.activeSourceUrl||s.sourceUrl,s.historySource||'参考收益率来源')+'</small></td></tr>';}).join('');
 const selected=$('#bond-series').value;$('#bond-series').innerHTML=b.bonds.map(s=>'<option value="'+esc(s.id)+'">'+esc(s.name+' · '+s.isin)+'</option>').join('');if(b.bonds.some(s=>s.id===selected))$('#bond-series').value=selected;else if(b.bonds.some(s=>s.entityId==='ORCL'))$('#bond-series').value=b.bonds.find(s=>s.entityId==='ORCL').id;renderBondHistory();
}
function renderBondHistory(){renderCreditHistory();}
$('#gpu-filter').onchange=()=>{if(gpuData)renderGpu(gpuData)};$('#gpu-series').onchange=renderGpuHistory;$('#bond-series').onchange=renderBondHistory;

function researchPanel(title,text,metrics,limits){return '<div class="eyebrow">本期结论 / 随证据更新</div><h3>'+esc(title)+'</h3><p>'+esc(text)+'</p><div class="research-metrics">'+metrics.map(m=>'<span>'+esc(m)+'</span>').join('')+'</div><small>'+esc(limits)+'</small>';}
function renderResearch(){const r=current?.research;if(!r)return;
 const p=r.pricing;$('#pricing-conclusion').innerHTML=researchPanel(p.title,p.text,['可比供应商 '+p.providers+' 家','可比固定规格 '+p.qualified+' / '+p.total,'上涨 '+p.up+' · 持平 '+p.flat+' · 下跌 '+p.down],p.threshold+' '+p.limits);
 const c=r.credit,score=c.score,labels=['未达阈值','预警','压力'],level=x=>x==null?'证据不足':labels[x];
 $('#credit-conclusion').innerHTML=researchPanel(c.title,'分别观察CDS利差，以及公司债YTM减同日5年美债的利差，是否持续走阔或收窄。以下每家公司保留自己的实际比较区间。',['核心公司覆盖 '+c.covered+' / '+c.coreTotal,'CDS压力等级：'+level(score?.cds.level),'公司债压力等级：'+level(score?.bonds.level)],c.limits+' 评分：'+(score?.rule||'暂缺'));
 $('#credit-overview').innerHTML=c.companies.map(s=>{const d=s.cds,b=s.bond;return '<tr><td><b>'+esc(s.name)+'</b><small>'+esc(s.entityId)+(s.core?' · 核心云厂商':' · Neocloud旁证')+'</small></td><td class="number">'+(d?.latest?num(d.latest.value,1)+' bp':'—')+changeBadge(d?.monthChange?{...d.monthChange,delta:d.monthChange.delta}:null,'bp',!s.cdsValid)+'<small>'+esc(d?d.measurement==='daily_close'?'公开日线':'DTCC合格成交中位数':'缺少合格连续序列')+'</small><small>'+link(d?.sourceUrl,'CDS来源')+'</small></td><td class="number">'+(b?.latest?.spreadBp!=null?num(b.latest.spreadBp,1)+' bp':'—')+changeBadge(b?.monthChange,'bp',b?.stale)+'<small>'+esc(b?.historySource||'')+' · '+esc(b?.latest?.asOf||'—')+'</small><small>'+link(b?.activeSourceUrl,'债券来源')+'</small></td><td>'+esc(s.conclusion)+'</td></tr>';}).join('');renderCreditHistory();
}
function creditComparisonChart(series){
 const data=series.flatMap(s=>s.points);if(!data.length)return '<p class="blank">尚无可比信用历史。</p>';
 const W=1000,H=330,L=65,R=25,T=28,B=45,dates=data.map(p=>Date.parse(p.date)),loDate=Math.min(...dates),hiDate=Math.max(...dates),values=data.map(p=>p.value);let lo=Math.min(...values),hi=Math.max(...values),pad=(hi-lo||Math.abs(hi)*.05||1)*.15;lo-=pad;hi+=pad;
 const x=d=>L+(Date.parse(d)-loDate)/(hiDate-loDate||1)*(W-L-R),y=v=>T+(hi-v)/(hi-lo)*(H-T-B);
 const legend=series.map(s=>'<span style="display:inline-block;margin:8px 24px 0 0"><i style="display:inline-block;width:18px;border-top:3px solid '+s.color+';margin-right:7px"></i>'+esc(s.name)+(s.points.length?' · '+esc(s.points[0].date)+' → '+esc(s.points.at(-1).date):' · 暂无合格数据')+'</span>').join('');
 const grid=Array.from({length:5},(_,i)=>{const v=lo+(hi-lo)*i/4;return '<line x1="'+L+'" x2="'+(W-R)+'" y1="'+y(v)+'" y2="'+y(v)+'" stroke="#d5d5d5"/><text x="'+(L-10)+'" y="'+(y(v)+4)+'" text-anchor="end" fill="#787878" font-size="12">'+num(v,1)+'</text>';}).join('');
 const lines=series.map(s=>{let path='',prev;for(const p of s.points){path+=(!prev||Date.parse(p.date)-Date.parse(prev)>7*86400000?'M':'L')+x(p.date)+','+y(p.value)+' ';prev=p.date;}return '<path d="'+path+'" fill="none" stroke="'+s.color+'" stroke-width="2.5"/>'+s.points.map(p=>'<circle cx="'+x(p.date)+'" cy="'+y(p.value)+'" r="3.5" fill="'+s.color+'"><title>'+esc(s.name)+' · '+esc(p.date)+' · '+num(p.value,2)+' bp</title></circle>').join('');}).join('');
 const ticks=Array.from({length:4},(_,i)=>{const t=loDate+(hiDate-loDate)*i/3,d=new Date(t).toISOString().slice(0,10);return '<text x="'+x(d)+'" y="'+(H-12)+'" text-anchor="'+(i===0?'start':i===3?'end':'middle')+'" fill="#787878" font-size="12">'+d+'</text>';}).join('');
 return '<div class="credit-legend">'+legend+'</div><svg viewBox="0 0 '+W+' '+H+'" role="img" aria-label="公司债信用利差与美元CDS共用bp轴对比" style="width:100%;display:block">'+grid+lines+ticks+'</svg>';
}
function renderCreditHistory(){
 const s=bondData?.bonds.find(s=>s.id===$('#bond-series').value),c=current?.research?.credit.companies.find(c=>c.bond?.id===s?.id);
 $('#credit-company-reading').textContent=c?c.name+'：'+c.conclusion+'。':'正在读取信用交叉证据…';
 $('#credit-history').innerHTML=creditComparisonChart([
 {name:'公司债信用利差（减同日5年美债）',color:'#dc2626',points:monthPoints((s?.rows||[]).filter(r=>r.spreadBp!=null)).map(r=>({date:r.asOf,value:r.spreadBp}))},
 {name:'5年期美元CDS · '+(c?.cds?.measurement==='trade_median'?'DTCC成交中位数':'公开日线'),color:'#dc2626',points:monthPoints(c?.cds?.rows||[]).map(r=>({date:r.asOf,value:r.value}))}
 ]);
}
